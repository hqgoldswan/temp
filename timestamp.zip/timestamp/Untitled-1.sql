
create tablespace DATA_001
datafile '/u01/app/oracle/product/11.2.0/xe/dbs/DB_data_001.ora' size 10 M
autoextend on next 10 M maxsize unlimited
default storage ( initial 64 K next 64 K
                 minextents 1 maxextents unlimited
                  pctincrease 0 )
online;

CREATE TABLE C_HELI_MST
(
    FUSE_NO             CHAR(4),
    HERI_NAME           CHAR(40),
    PREF_NO             CHAR(2),
    CAR_NO              CHAR(6),
    DISP_ORDER          NUMBER(10),
    USE_START_DATE      TIMESTAMP,
    USE_END_DATE        TIMESTAMP,
    UPD_DATE            TIMESTAMP,
    PRIMARY KEY (FUSE_NO)
)
tablespace DATA_001 ;
