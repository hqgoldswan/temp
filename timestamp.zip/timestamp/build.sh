
/u01/instantclient_11_2/sdk/proc iname=sample.pc MODE=ORACLE sqlcheck=full hold_cursor=NO release_cursor=YES maxopencursors=250 select_error=no PREFETCH=0 DEFINE=SERVER_NO DEFINE=PRE_UNIX
make
./sample.exe
