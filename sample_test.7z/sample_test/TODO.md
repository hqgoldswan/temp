http://srikanthtechnologies.com/blog/oracle/procgetstarted.aspx

# TODO
## Programming task:
 - What is VARCHAR in ProC
 - Set up to use LLVM with easyclang plugin to autocomplete C/C++ source code.
 - Study makefile firmly
 	+ To work with Java source code also.
 - Check the with a An the name of source code reference tool and try to set-up in my local ubuntu server.
 - Check what are the following option in gcc when compiling:
 	+ -lm
 	+ -lclntsh

## Discuss with a Vu for starting earlier preparation:
 - Car team:
* VM with HiRDB, MAULA installed or HiRDB, MAUL license
* Official design for some component
* Sample source code, header with comment

## Sublime setting contents
```
{
	"auto_complete_selector": "source - comment, meta.tag - punctuation.definition.tag.begin",
	"auto_indent": true,
	"color_scheme": "Packages/Darkula Color Scheme/darkula.tmTheme",
	"detect_indentation": true,
	"draw_white_space": "all",
	"font_size": 13,
	"ignored_packages":
	[
	],
	"indent_to_bracket": true,
	"open_files_in_new_window": false,
	"translate_tabs_to_spaces": true,
	"trim_automatic_white_space": true,
	"trim_trailing_white_space_on_save": true,
	"use_tab_stops": false,
	"vintage_ctrl_keys": true
}
```

## Source code understanding:
### Receive and process information from PSD device:
C:\workspace\APP_project\Car\sample_source\Car\Serv\Include\psd_header.h
C:\workspace\APP_project\Car\sample_source\Psd\Program\CA08\CA0810_PsdRecvPic\Source\CA0810_PicListC.c
    185 n1Rtc = OnPicListMain(tblShrMemData.file_path, n4BodySize, &tblShrMemData) ;

## Van co gang khi:
 - Van con co cai de lam
 - Van con duoc support va tra luong

## Muc tieu & Muc dich:
	- Muc dich: La hieu duoc design he thong 1 cach solid
	- Muc tieu: design ra duoc SQL statement.
		+ Thi luc lam SQL minh se can check nhung process de biet duoc he thong bao gom nhung he thong nao.
		+ Can phai check he thong co nhung data gi, va nhung data gi duoc truyen qua lai giua cac thanh phan ben trong he thong.

## Muc tieu & muc dich cua cong viec:
 - Muc tieu:
 	+ Lam ra duoc nhieu tien cho cong ty outsource
 	+ Giu duoc nguoi de co the lam viec cho cong ty
 - Nhiem vu:
 	+ Get, manage requirement voi muc tieu la co the implement duoc
 		+ Check technical to ensure current requirement is enough for implementation
 		=> To do this, you need to implement some sample program for one requirement to make sure the requirement is enough for implementation.
 			- Muon biet la du hay khong, thi tot nhat la lam thu de biet la:
 				+ No can gi
 				+ De co the danh gia duoc 1 input la du hay khong du
 	+ Discuss with customer about unclear requirement or any issue
 	+ Discuss with team to help them understand the requirement
 		=> In order to do this, most of the time you need to translate their question and answer from customer.
 - Muc dich:
 	+ Phat trien nhan thuc ve con nguoi
 	+ Phat trien kha nang ky thuat, ngon ngu cua minh
 	+ Biet cach lap ke hoach cho mot ket qua nao do, follow ke hoach
 		- De di den mot ket qua to lon, thi can phai chia nho van de ra
 		- Assign moi nguoi 1 viec, di den dich do.
 	+ Nguoi co kinh nghiem kha nang la nguoi thay duoc con duong, cach thuc cac ben cong tac de di den dich.

## Cach tuyen leader:
 - Leader la nguoi giu gin gia tri cua group
 - Do do, de dam bao gia tri ma minh muon gin giu thi phai confirm 1 cach ro rang gia tri ma nguoi lam leader do huong toi la gi.

## Personal
	- Checking reverse mind map method (Maybe, in this case Excel is helpful)
	- Check cach bay to long biet on, su ton trong voi gia tri minh nhan duoc tu nguoi khac.
	- Check 仕事で挨拶ガイドライン
	- TCP/IP in Linux Programming
	- Inter Process Communication
		+ Message Queue
		+ Shared Memory
	- Encryption in C programming
	- Coverity for C source code

## Generic plan
 - D layer
 	+ DAO definition
 		- Generic SQL definition for each table [DONE]
 		- Specific SQL definition for each process in SOA diagram derived from System Use-Case [In-Progress]
 			+ Current: update AA07_02_20_D層インタフェース一覧表_ヘリ動態履歴期間管理.xls in Car, the rest is 20 -> 34 of Car and PSD, IPR

 - F layer: Realize each process in SOA diagram to class design and corresponding functional design.
 	+ Class diagram [Not started yet]
 	+ Functional definition [Not started yet]


## 20180109
 - Check updated message interface
 - Prepare environment for creating sequence diagram
 - Create SQL definition:
 	+ 39, 32 [DONE]
 	+ Current: 60 - IPR
 		- Confirm: IPD or IP only?
 			+ Answer: IPD for only one device
 					IP only is for both IPR and IPW device

# Note
## System understanding:
	- Car location has following functional:
		+ (1) Movement management: Car, PSD, PSW, IPR, IPW, Helicoper
		+ (1) Business management: Jian, 110, Emergent case, Remote control, Lock control
		+ (2) Receive image: from Car, PSD, IPR
		+ (2) Send image: to Car, PSD, IPR
		+ (3) Receive video: from Car (PIC on-the-scene)
		+ (3) Cooperate with video replaying service: cooperate with user on-the-scene, map, common system
		+ (4) Cooperate with Transport control service: get transport infor from Transport System, manage it, send to client.
		+ (4)Display movement status at another prefecture: Send our movement data to the corresponding system of another prefecture.
		+ (4) Cooperate with authentication system: cooperate with authentication server to authenticate PIC on-the-car.
		+ (5) Maintenance car of self-prefecture: cooperate with common system, then parse csv file to register master file of our own prefecture
		+ (5) Maintenace car of another prefecture: cooperate with common system, then parse csv file to register master file of other prefectures.
		+ (5) Maintenace for sending frequency: cooperate with common system, then parse csv file to register updated master file of sending frequency.
		+ (5) Maintenance for closing area: cooperating with common system, then parse csv file to register updated master Closed area.
		+ (5) Maintenace for usage: cooperating with common system, then parse csv file to register updated master Usage information.
		+ (5) Maintenace for business status: Cooperating with common system, then parse csv file to register updated master Business Status.
		+ (5) Maitenance for the name of Calling place: Cooperating with common system, then parse csv file to register updated master Naming information.
		+ (5) Notify the updated Master update: update Master file when user request update Master file from client with updated master file specified by user. (CSV parsing)
		+ (5) Setting enable/disable Jian request: receive signal to enable/disable Jian request.
		+ (6) Business controll: ???
		+ (7) Statistic: automatically summarize statistic information, deliver it to client when there is request.
		+ (8) Disaster: set Disaster mode to the car from Service Operator.

## Interface message note
		- 文字列タイプ		なし			：文字列(左詰め・半角スペースでパディング)
				N			：数値(右詰め・"0"でパディング)
				DT			：日時(YYYYMMDDhhmmss)
				D			：日付け(YYYYMMDD)
				Y			：年(YYYY)
				M			：月(MM)
				d			：日(DD)
				T			：時分秒(hhmmss)
				Ｈ			：時(hh)
				m			：分(mm)
				s			：秒(ss)
				BIN			：バイナリデータ

バイトサイズ		文字列のバイトサイズ

入力制限			●			：必須入力項目
				◎			：必須入力項目（繰り返し項目内での必須入力項目。繰り返し回数が０の場合は必須対象外とする。）
				○			：任意入力項目（値が未設定の場合は半角スペースでパディングする。文字列タイプＮは"0"でパディングする）


## Preparation for implementation:
		+ (HiRDB manual)[http://itdoc.hitachi.co.jp/manuals/3020/3020645640/W4560001.HTM]

## For daily work
 - SQL statement definition:
 	+ 物理名: CHelistrDaoUoc
 		- At the beginning: add character "C"
 		- At the end: add character "DaoUoc"
 	+ メソッドID: searchCHelistr, changeCHelistr, entryCHelistr, removeCHelistr
 		- At the beginning of the method name: we need add keyword "search", "change", "entry", "remove" for corresponding purpose of SQL statement
 		- At the end of method name:
 			+ In the generic case: we don't have to add any word to indicate the generic case
 			+ But in some specific case: we need to add some supplement word to illustrate the meaning of SQL statement like searchXXXall, searchXXXonly...
	+ SQLID: C_HELISTR_SCP_TABSP, C_HELISTR_SCP_TABUP, C_HELISTR_SCP_TABIP, C_HELISTR_SCP_TABDP
		- At the end of the word, we need to add SP, UP, IP, DP correspondingly
		- When there is more specific SQL statement definition come up from SOA diagram: we can add it to SxxP, UxxP, IxxP, DxxP
	+ For parameter information:
		- In case there is many table with same structure, and their name is identified by ???, NNN
			+ We need to add one additional parameter to indicate the table name like:
				- I/O	データ項目名				繰返し	データ型	桁数		小数部桁数
						論理名		物理名
				- I		テーブル名称	TABLE_NAME	-		CHAR	20		-
 	+ File name, table name:
 		+ ending with マスタ is prohibited, we must use マスタ情報
 		+ The keyword "システムロック" is not allowed, we must use "端末ロック"

## About Linux programming
 - https://github.com/hustcalm/linux-getting-started

## Misc information
 - Color information from Acrobat Reader
 	+ Background: 77, 77, 77
 	+ Foreground: 194, 194, 194

 - Hoc gioi thi chung minh duoc mot dieu la minh co kha nang, ky nang lam duoc cong viec kho va hieu duoc de lam duoc viec kho thi can ke hoach, thai do, tinh than va kha nang nhu the nao:
 	+ Nhung neu minh khong lam thi khong co ket qua nao xay ra

 - Yeu thuong neu khong kheo thi se lam nguoi minh yeu thuong bi liet:
 	+ Ban chat cua con nguoi la phai phat trien hoan thien, phai tu lo cuoc song cua minh tu dau den cuoi, o tat ca cac mat cua cuoc song. Co nhu vay, thi con nguoi moi phat trien toan dien duoc.
 	+ Yeu thuong la giup cho nguoi minh yeu thuong co the lam duoc viec do mot cach tot nhat, chu khong phai la khong cho nguoi minh yeu thuong lam gi:
 		- Neu minh khong de cho nguoi minh yeu thuong, thi nhung mat ma minh khong cho phat trien se bi liet.
 	+ Vi du:
 		- Moi nguoi deu co doi chan, no dung de nang co the va di lai.
 		- Neu yeu thuong la ta thay viec di lai met moi, ta khong cho nguoi ta yeu thuong di, thi doi chan se bi teo, khong hoat dong duoc.
 			+ No tuong tu cho cac mat khac cua cuoc song
	+ De song mot cuoc song co y nghia, la con nguoi phai song mot cuoc doi tu te. Song trong nang luc cua minh.

 - Truong thanh la gi: do la kha nang giai quyet duoc cac van de lon
 	+ Nang luc chuyen mon:
 		+ Kha nang hoan thanh task cua chinh minh
 		+ Hieu duoc, de giai quyet duoc 1 van de lon. Thi can moi nguoi 1 viec, va viec cua leader la gi, nguoi khac la gi. Mot nguoi khong the giai quyet duoc moi thu.
 	+ Nang luc quan ly cam xuc:
 		- Luon dam bao minh co the phat huy het nhung kha nang cua minh
 		- Kien nhan voi nguoi khac, khi ket qua chua duoc nhu y
	+ Bieu hien cua leader:
		- Luon co the dua ra output tot nhat cua minh trong moi hoan canh:
		- Khong noi nong
			+ Du chuyen gi xay ra, thi cung quy no thanh hanh dong va dung kha nang tot nhat cua minh de giai quyet tung van de mot


 - Tren buoc duong truong thanh, minh can lam & ghi nhan nhung thanh qua cua minh (dua tren ke hoach minh da dat ra). O moi milestone minh nen luu lai ky niem bang cac:
 	+ Hien vat
 	+ Hien vat luu niem

 - Support site:
 	+ https://www.briantracy.com
 	+ https://curiousmindmagazine.com/5-crucial-factors-for-living-a-happy-life-according-to-carl-jung/
 	+ http://www.e-japanese.jp/?p=1092 <-- Learning Japanese online
 	+ http://www.tanos.co.uk
 	+ http://otanishoten.jp/kikansiyorist.html <-- JLPT learning material
 	+ http://muatuongphat.com/sach-phat-giao/kinh-tung/Kinh-Dia-Tang-Bo-Tat-bon-nguyen-73.html <-- Kinh phat
 	+ https://www.sachkhaitam.com/thien-yoga/dai-tang-kinh-tron-bo-37-tap <-- tron bo kinh phat (nha sach khai tam)

### Trong cuoc song, de di thi minh can 2 dieu:
 	+ Muc tieu:
 		- La Target nho de huong toi, thong qua do minh se dat duoc muc dich (Purpose).
 			+ Ban co nhieu cach de xu ly viec nay. Chi tap trung lam sao de dat duoc Target khong thoi.
 			+ Hoac la vua dat duoc target, vua danh it thoi gian de nhin tong quat, nham muc dich giup minh dat duoc Purpose da dat ra.
 		- Trong qua trinh huong toi muc tieu, collect nhung yeu to cau thanh nen Purpose cuoi cung.

 	+ Muc dich:
 		- Purpose la mot cai lon, no bao gom nhieu muc tieu. Nhung de hien thuc het Purpose 1 luc, thi khong the nao hoan thanh duoc.
 		- Define duoc dau la cac yeu to can thiet, de dat duoc muc dich cuoi cung.
 			+ Thuong do la cac nguyen lieu giup minh dat duoc cac target cao hon.

### How to be peaceful:
 - Life is all about balance. You don't always need to be getting stuff done.
Sometimes it's perfectly okay, and absolutery necessary, to shut down, to sit back and do nothing.

 - Life is all about balance and following what the universe provides for you.

 - Life is about balance. Be kind, but don't let people abuse you. Trust, but don't be deceived. Be content, but never stop improving yourself

### Cac yeu to de cuoc song can bang: phat trien nang luc chuyen mon va nang luc cam xuc thong qua: don gian la thoa man tat ca cac giac quan tren co the, phat trien chung:
	- Nao
	- Chan tay
	- Co quan sinh duc
	- Trai tim
	- 2 cam giac ma con nguoi yeu cau nhieu nhat:
		+ Cam giac duoc kinh trong
		+ Cam giac duoc thoa man tinh duc
#### Target:
	- Co cong viec de lam
	- Co cuoc song the thao
	- Co nguoi de yeu thuong
	- Co ban be de cam thay huu ich
	- Co gia dinh, de quan tam
#### Purpose:
	- 1) Peace Of Mind
	- 2) Health And Energy
	- 3) Loving Relationships
	- 4) Financial Freedom
	- 5) Worthy Goals And Ideas
	- 6) Self Knowledge And Self-Awareness
	- 7) Personal Fulfillment

### Misc TODO:
	- Pareto Principle
	- Focal point, The Psychology of Achievement, Time Management
### Tai sao tong thoi gian de lam 1 viec, thi viec chi tinh thoi gian lam la giet nguoi:
	- Vi thoi gian de lam 1 viec gom co: (Plan - Do - Check - Action + Search support/relating information)
		+ Hieu viec
		+ Len plan
		+ Tim hieu cac thong tin can thiet
		+ Lam viec (thong thuong chi chiem 20% tong effort de hoan thanh cong viec)
		+ Kiem tra ket qua

### Ke hoach & thuc hien:
#### Lap ke hoach
 - Len ke hoach cho ae = 75% kha nang cua minh
 - Luon luon bo them thoi gian de tim hieu them thong tin xung quanh van de

#### Thuc hien:
 - Luc thuc hien thi viec dau tien la tap trung hoan thanh cong viec chinh.
 - Thoi gian con lai thi tim hieu cac van de xung quanh cong viec chinh de kien toan kien thuc cua minh cho van de do.

### Summarization for Communication with Nakaoka-san:
 - Communication module includes:
 	+ Communication with 110 system
 		- Customize the library module from system on Car application.
 			+ Enabling 4 persistent connections comparing to 1 as system on Car.
 	+ Server communicate with Client application
 		- Just change a little based on current system's source code
 	+ Client communicate with Car Location server
 		- Customize the library module from system on Car application. Changing persistent connection to connection on-the-call.
 	+ Communication with external system (PSD, Car, Traffic Control System, Disaster Information System, Other prefecture Car Location, PSD, IPR, Heli, Exist Car Location system)
 		- Re-use from current system

### De phat trien tren duong doi thi can 2 cai:
 - Manh ve nang luc ky thuat, giai quyet duoc cac van de ve ky thuat
 - Manh ve nang luc cam xuc (Giu duoc cam xuc cua minh):
 	+ Dam bao minh luon co the lam duoc het kha nang cua minh.
 	+ Dam bao minh khong bao gio noi nong.

### Ban chat cua cac hoat dong tren the gioi (tat ca moi hoat dong tren the gioi deu trai qua qua trinh nay):
 - Dau tien luc chua nong, thi no tu tu, ue oai => cam giac khong muon lam
 	+ Doi voi tinh trang nay, thi warming up tu tu
 - Lam tu tu 1 hoi, den luc sung len thi muon lam rat la nhieu
 	+ Doi voi tinh trang nay, thi tranh thu lam nhieu nhat co the. Vi day la luc hieu qua nhat doi voi cong viec
 - Lam mot hoi met moi thi muon nghi ngoi
 	+ Doi voi tinh trang nay, thi nhe nhang sum up (take note) cong viec cac kieu de ket thuc 1 qua trinh

 - 3 giai doan do, no cu xoay vong, lap lai ngay qua ngay o hinh thai nho. Roi no lap lai o muc do lon hon, trong cuoc song o hinh thai lon hon.

### Emotional intelligence is how to keep calm, be professional and pleasant in all case in order to ALLOW YOU TO HAVE THE BEST SOLUTION FOR ALL CASES:
For me, don't do following thing:
 - Don't Get angry, when problem occur => Problem occur because we didn't handle it well. Just that it.
 - Don't Blame people in public => If you want tell some body something they don't want to know, please keep the conversation in private.
 - Don't Discuss about the other's behavior => Just tell them what we need them do, that's it.

### Tai sao minh phai lien tuc di va set muc tieu:
 - Vi khi co 1 muc tieu tot de co gang, thi minh se dat tam tri, co the, ke hoach cua minh vao dieu do. Muc dich la de tranh cac van de vun van cua cuoc song va dat duoc cac muc tieu cao hon, tot dep hon cho chinh minh va cuoc song xung quanh:
 	+ Khi minh phai giai quyet cac van de nao do, thi minh phai can co the minh o trang thai tot nhat => do la co so de minh co the giu minh. Tranh khoi cac van de khong dang co.
 - Set cac muc tieu do thanh ra cac ket qua co loi cho minh va cho cong dong =>
 	+ Cuoc song vua y nghia va
 	+ Co co so de vuot qua cac dau kho hang ngay cua cuoc song, biet dau la diem dung lai de co time & suc luc de giai quyet cac van de ma muc tieu minh dat ra.

 - Minh khong the nao song tot duoc, neu nhu minh khong de cac kha nang tot ben trong minh duoc thoa man. Giong nhu 1 chiec xe dap, neu minh khong cho cac banh xe quay, tay dieu khien, oc phan doan, thi chiec xe se dung lai va nga boi
 	+ Su mat can bang von la can ban cua con nguoi
 	+ Su tac dong (trong luc, gio, khong bang phang cua mat duong) von co cua cuoc song.

 - Nguoi linh dung la can nghi ngoi, nhung neu khong ra chien tran, thi nguoi linh se bi liet het tat ca cac ky nang, va se khong bao gio co the tro thanh nguoi linh duoc nua.

 - Khi nguoi linh met moi, thi ho se chuyen sang vai tro to chuc. O do, ho khong truc tiep di giai quyet van de nua, ma ho se dung kinh nghiem cua minh de dat dung nguoi, dung viec nham giai quyet van de cuoi cung:
 	+ Ve co ban, thi tat ca moi nguoi cung nhau lam. Giai quyet van de.

 - Khi khong ai tra loi cho minh cac cau hoi ve cuoc song, thi minh hay tu di tim cau tra loi bang chinh kha nang cua minh. Do la mot hanh trinh rat dep va tuoi vui.

### Lam du an la gi:
 - La di giai quyet va ngan cac van de cua du an co the phat sinh.
 - Nguoi lam tot la nguoi lam khong co 1 van de nao ca, vi:
 	+ Ho da de phong va dua ra cac giai phap cho cac van de cua du an.
 - Nguoi co kinh nghiem, la nguoi:
 	+ Biet cac van de co the co cua du an tu dau den cuoi va dua ra cac giai phap nham giai quyet, ngan chan cac van de do nay sinh mot cach hieu qua va it ton suc nhat.
 	+ Va la mot nguoi khong bao gio chu quan doi voi cac van de tiem nang, du la ho co kha nang giai quyet no.

### Kinh nghiem cua viec song lau:

 - Khong ai co cung cach nhin, quan niem song voi minh.

 - Tren con duong phat trien cua minh, minh chinh la nguoi hien thuc dieu minh tin tuong la dung.

### Con nguoi la tong hop cua cac chat tao nen con nguoi:
 - The thao: tao ra chat yeu doi, suc luc.

 - Cong viec, challenge: tao ra chat calm, professional and efficiency.
 	+ Luc nao cung can phai tinh tao, binh tinh. De co the nho va giai quyet cac van de ma challenge minh dang phai lam. Neu khong nho, thi khong the nao giai quyet van de mot cach fluently. Dung la phai luu lai, vi dau oc khong the nho het duoc.
 	Nhung nen nho mot dieu, la luu lai, la giup cho dau oc co the check lai neu quen. Vi ban chat la ban than minh phai tra loi cac cau hoi.
 		- Tat ca cac tai lieu, summarization la de giup minh. Van de la o ban than minh.
 	+ Luon hoc tieng Nhat & ky thuat de dam bao dieu nay => luc nao cung phai nho chu tieng nhat va cac van de ky thuat.

 - Tinh cam: tao ra chat binh yen, am cung va an toan - giai tru cac kho khan, moi met cua cuoc song.
 - Tinh ban: tao ra su chia se, giup do nhau => cam giac giup do duoc ban be.

 - De giu ban than tranh xa duoc cac van de san si binh thuong cua xa hoi, thi can hanh dong dung trong 1 ngay:
 	+ Warming up: in case of learning language -> a list of word for a day. All of the day, thinking about it to keep your self calm, pleasant and professional. If not, you will fall to very small talk of normal day.
 	+ In case of doing other things, check and update TODO list, progress. Thinking about TODO item of the day, and keep your self calm, pleasant and professional to have them done.

### Danh gia ve con nguoi:
 - a Tam:
 	+ La nguoi ton nhieu suc vao cac viec khong can thiet, va khong giup ich gi cho du an.

 	+ Ve mat du an, thi khong nghi la anh Tam la nguoi thich hop de lam tong PM cua toan du an, vi:
 		- a Tam khong dung suc hieu qua, ton qua nhieu suc luc vao viec tao ra va giai quyet cac van de tao lao.
 		- Lam viec theo tieu chi phi li, dan den dua ra nhung quyet dinh khong hop ly.

 	+ La mot nguoi thuoc thanh phan gay su, co nghia la nguoi chuyen sinh ra van de. De giai quyet van de tu nguoi nay, thi het mat thoi gian giai quyet van de khac.
 		=> Do la tam ly cua tre con khi con nho. De biet duoc nguoi khac co quan tam minh hay khong, thi gia vo co gang tao ra van de, de xem nguoi lon co quan tam minh hay khong. Va luon luon nhu vay, do do nguoi khac se met moi, mat het thoi gian va nang luong, de giai quyet cac van de can giai quyet khac cua cuoc song.
 				=> Khong nen tap trung, chap nhat qua nhieu den nhung nguoi mang tinh tre con. Xac dinh ro cac van de can giai quyet khac cuoc song, project la gi, giu minh thu nang luong de tap trung giai quyet chung va dua ra yeu cau ro rang cho nhung nguoi mang tinh cach tre con do.
	=> De a Tam lam PM tong cua du an, thi se dan den mot van de la khoi luong cong viec lam ra se khong duoc nhieu, vi suc luc de giai thich, khuyen can, nhan dinh van de la qua nhieu. Ma trong khi do 1 ngay chi co 8 tieng.

	+ Tai sao kho lam viec duoc voi a Tam: vi 7/10 nang luong cua anh Tam la dung de tao ra van de, cho 3/10 nang luong la dung de giai quyet van de.

 - Nguoi co tinh cach tre con:
 		+ La khong dung nang luong cua minh de giai quyet van de, ma dung nang luong cua minh de tao ra van de nham:
 			- Chung to ban than
 			- Tim kiem su quan tam tu nguoi khac.

 		+ Tre con khac voi nguoi lon o cho: nguoi lon la nhung nguoi dung nang luong cua minh de giai quyet van de.
 			- Tre con la nguoi dung nang luong cua minh de tao ra van de nham:
 				+ Gay chu y
 				+ De biet nguoi khac co quan tam minh hay khong.
 			- Doi voi nhung van de cua tre con, thi can quan tam 1 phan khi co thoi gian.
 				+ Ignore no, de giai quyet cac van de can thiet khac.
 				Vi khi qua chu y den tre con, thi no se cang tao ra nhieu van de hon de giai quyet, roi thay la nguoi khac quan tam den minh.
 				+ Goc re cua van de la minh can phai

 		+ Nguoi lon la nguoi thay cuoc song day niem vui voi viec giai quyet cac van de ben ngoai.

 - Dac tinh cua nhung nguoi co tinh cach tre con & nguoi lon:
 + Nguoi lon: Tap trung va hop tac de giai quyet van de cua cuoc song
 + Tre con: Giai quyet 1 vai van de, nhung lai tao ra nhieu van de khac
 	+ Vi du: nhe ba me minh. Giup giai quyet cac van de nhu la com nuoc, nha cua sach se... cac van de huu hinh.
 		- Nhung lai tao ra cac van de vo hinh, nhu khong khi nang ne. Cam giac ap luc, su chi trich lan nhau.
 			+ Dua ra nhieu yeu cau phai the nay, phai the kia.
 			+ Treu gheo nhau de lam cho minh vui.
 			+ Si nhuc nguoi khac, de tao cam giac minh hon nguoi.
 		- Su si nhuc nguoi khac la van de lon nhat ma ba me minh dem lai.
 	=> De giai quyet van de nay, thi minh chi thuc su lam cho nguoi khac, khi nao ma minh cam thay thoai mai nhat. Khong can phai noi nang gi, si nhuc nguoi khac thi lam.
 	Doi khi lam can 1 trong 2 yeu to:
 		+ Thu lao
 		+ Hoac la su cong nhan, thuong ho muon dat duoc bang cach si nhuc nguoi khac. Noi di noi lai, de nguoi khac cong nhan.
 		=> Minh khong can su cong nhan tu nguoi khac, thi cuoc song se tuoi dep hon rat nhieu.

 	=> De han che dieu nay, thi minh nen noi loi cam on, cong nhan cac gia tri ma nguoi khac mang lai cho minh mot cach chan thanh va dung dan.
 		+ Can hoc cach the hien, bay to long cam on, va su cong nhan cac gia tri ma nguoi khac mang lai cho minh. (=> Cai ma minh thieu va can improve)
 		+ Lam mot dieu gi do cho nguoi yeu thuong, thi khong can phai nhan lai gi ca. Vi khi minh can nhan lai qua nhieu, thi minh se roi vao trang thai ham thich nhung dieu minh can nhan lai.
 			- Doi voi nguoi ngoai, thi viec minh lam ra can phai co su nhan lai tuong ung.
 		+ Trong cong viec o cong ty, thi gia tri minh nhan lai da la co dinh: bang tien thu lao hang thang. Thi minh tao ra gia tri het suc co the trong gioi han cho phep, va khong yeu cau cac gia tri khac tu nguoi khac. (Dung si nhuc, dung nay no voi nguoi khac)
 		+ Doi voi viec bi nguoi khac noi, si nhuc nay no. Minh can biet la tai sao nguoi ta lai noi nhu vay. Doi khi nguoi ta can su cong nhan minh gioi, cong nhan cac gia tri minh lam ra. Thi de giai quyet van de do, ma van nhan duoc su giup do cua nguoi khac, thi minh can phai bay to su biet on, tran trong cua minh.
 		+ Nguoi thich si nhuc nguoi khac, hay noi di noi lai. Thuc ra la vi nguoi ta qua tham lam, muon nhan duoc nhieu. Co 2 loai gia tri, thu lao va su cong nhan. Nhung nguoi muon nhan duoc nhieu, thuc ra la vi ho tham lam muon nhan nhieu thu. Nhung nho la minh nhan nhieu thu, thi vi gia tri la can bang, nen khi minh nhan nhieu, thi nguoi khac se mat nhieu. (Luon nho dieu do).
 			=> Minh chi nhan thu lao, con cho nguoi khac su cong nhan, su vinh quang.

 		+ Doi voi con nguoi, gia tri ma ho coi trong nhat la nhan pham, chu khong phai la tien bac. Si nhuc con nguoi la mot cach lay di gia tri cao nhat cua nguoi khac, dem ve cho minh.
 			=> Thuong nguoi ta bao ve gia tri do cao nhat.

 - Tai sao tinh cach con nguoi lai kho thay doi:
 	+ Vi cuoc song hang ngay, ho dung nhung tich cach do, hanh dong hang ngay de tao ra cam nhan, gia tri de ho song hang ngay. Do do, neu thieu no di, ho se khong song duoc, mot dang bi nghien
 	+ De thay doi duoc, thi can phai tap lai nhung hanh dong moi, tu do tao ra thoi quen, va tinh cach thay the
 		+ Hanh dong => thoi quen => tinh cach => Hanh dong
 		+ Trong mot som 1 chieu, trong 1 buoi noi chuyen khong the nao thay doi duoc tinh cach cua 1 con nguoi. Do do minh can hieu tinh cach cua no 1 cach chan thuc, de biet duoc voi tinh cach do se co nhung hanh dong gi. De dua ra cach hoat dong thich hop.

### Tai sao khong nen chia se nhung chuyen personal len facebook:
 - No se anh huong den the gioi noi tai.
 - Nhung viec chia se len fb, do la nhung viec mang tinh public. Mon an danh cho toan thien ha.
 - Ai cung co nhu cau can chia se, can su cong nhan, khang dinh. Do la ly do ma khoe thanh tich, chia se chuyen ca nhan.
 	+ Nhung phai y thuc duoc fb la noi cong cong, khong nen chia se nhung du dinh ca nhan len do. Vi dem cai cay ra duong deo, thi khong bao gio thanh cai cay duoc.
 	O nhung noi public, thi minh dua nhung cai public can, chu khong phai nhung cai ca nhan cua minh can.

 - "Khong bao gio dem cai cay cua minh, ra deo giua duong"

### Tai sao nguoi ta lai thich di den nhung noi tot hon
 - Tai vi o do co nhieu hon su
 	+ Cong bang
 	+ Tu te
 	+ Cac gia tri song tot duoc de cao hon
 	=> Phat trien duoc cac gia tri song tot => Lam con nguoi tot len.

 - Cac gia tri song tot la gi?
 	+ Cong bang
 	+ Tinh than trach nhiem
 	+ Giup do nhau
 	+ Su kien tri, no luc phan dau

 - Cac gia tri song khong tot la gi:
 	+

### Ly giai ve kha nang con nguoi:
 - Kha nang cua con nguoi la huu han, giong nhu RAM cua may tinh.
 - Do do de hien thuc cai lon hon cai huu han do, minh can
 	+ Su giup do cua nhieu cai huu han (su hop tac cua nhieu bo RAM)
 	+ Viet ra tat ca cai huu han ma bo nao co, trong mot buc tranh lon. De giai phong bo nao khoi viec phai luu giu toan bo buc tranh.
 		+ Do la giong nhu viec backup xu ly vo RAM, chi lay ra nhung gi minh can luc can thiet.
 		+ Xu ly xong la phai luu het lai vo o cung, de tat may cho RAM nghi ngoi.
 	+ O cung o day co nghia la cac note, sach vo.

 - May tinh ai manh hon khi:
 	+ Toc do khoi dong va nap du lieu nhanh (Quan trong nhi)
 	+ RAM tot (Quan trong nhi)
 	+ Chuong trinh xu ly tot (Quan trong nhat)
 	+ Do nhanh cua processor (Quan trong cuoi cung)

 - De giup cho no xu ly tot hon thi minh can
 	+ Toi uu hoa viec luu du lieu => giup viec load vo bo nho nhanh hon
 	+ Mo rong RAM => luyen tap bang cach ghi nho tu vung daily
 	+ Toi uu hoa chuong trinh (can phai lam gi truoc, gi sau, moi lien he giua cac thanh phan voi nhau) => Dieu nay quan trong nhat
 	+ Tang toc xu ly => luyen tap qua viec tham gia cac ky thi co gioi han thoi gian.

### Trong cong viec tai sao lai can can than:
	+ Vi loi ich cong viec, minh khong biet khi nao thi con nguoi, nhan vien do chung

### Doi voi cac van de da lam, ma quen roi thi khong phai la tra loi khong biet, ma trar loi that la co lam roi, nhung bay gio da quen.

### Nguoi co kha nang cao ve emotional intelligence:
	- La nguoi luon giu duoc su binh tinh, professional trong moi hoan canh:
		+ De co the dua ra giai phap tot nhat cho van de.
#### Phuong phap de giu su thoai mai (phat trien y tuong nay den cung):
	- Ghi nho mot dieu, minh gioi len, phat trien tot hon. Thi khong viec gi phai kho chiu vi nhung dieu xau, chua tot ca.
		+ Cuoc song cua minh se phai tuoi dep hon, binh yen hon.
	- Song trong kha nang cua minh, kha nang minh gioi len, thi cuoc song cua minh phai nhieu bong hoa tuoi dep hon. Luon nho la nhu vay.
		+ Kha nang la gom co
	- Minh chi nen kho chiu voi chinh ban than minh, khi no khong lam duoc viec gi do. Khi no lam duoc viec, thi hay cho no duoc cam giac thay thoai mai, tan huong cuoc song
		+ Tat ca cuoc song nay deu quy thanh cac viec can phai lam, co gang.
		+ Nen nho, la co nhung viec minh chi cau mong the gioi nay mang lai dieu tot dep cho minh, chu minh khong co kha nang lam duoc. Neu minh co suc de lam nhung viec do, thi minh chi co dau kho vi khong lam duoc ma thoi:
			- Thay doi 1 con nguoi trong 1 tich tac

	- Neu minh kho chiu voi the gioi nay, thi minh se khong bao gio co du time, de giai quyet van de cua ban than minh.
		+ Ban thanh minh neu co kha nang giai quyet van de, thi hay cho no cam giac thoai mai nhu la 1 phan thuong.

	- Co 1 thuc te, la the gioi nay co rat nhieu problem, suc nguoi la co han. Mot minh minh giai quyet duoc nhieu van de, nhung neu nguoi khac khong giai quyet van de, thi kha nang giai quyet van de cua ca tap the se co han.
		+ Nhung co 1 contradiction la: nguoi ta hua voi nguoi khac kha nang giai quyet van de cua ca 1 tap the la rat lon. Nhung thuc te la khong duoc nhu vay.
		+ De han che no, thi minh can phai dua ra nhung van de thuoc ve Project Management (52 processes of Project Management):
			- Muc dich cua Project Managment la phat huy tot nhat kha nang cua team, de giai quyet van de.
			- Trong do van de quan trong nhat la: quan ly risk, issue va report.

	- Cong viec cua leader:
		+ Dua ra guide line, schedule
		+ Lam viec cua minh
		+ Report status cua toan team => analyse problem va cac action tiep theo

	- Cuoc song cua minh la gi, minh lam gi de kiem song va phan dau?
		+ Do la minh check/manage requirement.
		+ Kiem tra xem requirement la co the implement duoc hay khong duoi goc do la 1 developer (lam thu de biet la no co du, hay thieu).
		+ Hoc va phat trien kha nang phan tich do kho cua giai thuat.
	- Minh gioi, minh phat trien ky nang cua minh. Do la nham muc dich co 1 cuoc song tot, binh an.
		+ Cai minh cho the gioi
	Dua tren co so minh gioi, minh co kha nang lam viec. Thi cuoc song tot dep, vua phai voi kha nang cua minh do la dieu de tim duoc.
		+ Nhung thanh phan xau trong xa hoi, muon lay di cuoc song tot dep cua minh rat la nhieu.
		+ Hoi dau minh quan tam, lo lang den nhung thanh phan do lam gi.
	- Minh ton trong va dua vao moi quan tam cua minh nhung nguoi tot, tu trong.
		+ Nen nho 90% the gioi nay la do xam long.
	- Nhung thanh phan tao lao trong cuoc song, minh dung den ho thi cang met minh thoi.

	- Lam du an, tat ca la giai quyet van de. Chia nhau ra ma giai quyet:
		+ Van de ben ngoai: van de cua khach hang, van de cua noi ham du an (viec phai lam)
		+ Van de ben trong: van de ben trong noi bo team
		+ Ai giai quyet duoc nhieu van de, thi phan thuong nguoi do duoc nhieu hon. Cuoc song ho thoai mai hon.

	- Tuong tu nhu vay la cuoc song, do la 1 chuoi quan ly van de:
		+ Quan ly van de cua cuoc song, de mang lai tien bac, su hieu biet ve cuoc doi.
		+ Van de cua gia dinh: de mang lai su binh an, su am ap cua tinh cam gia dinh.

### Goc cua moi kho dau:
 - Do la long tham cua con nguoi:
 	+ Tham nhung gia tri vat chat, ngoai kha nang lam ra cua minh.
 	+ Tham nhung danh hieu, vi tri, su nguong mo cua con nguoi ma ban than minh khong dat toi duoc.
 	+ Tham nhung tinh cam, sac duc ma minh khong co kha nang bao ve no.
 - Song dung voi kha nang, nang luc cua minh. Do la goc cua moi niem vui.
 - Song tren cuoc doi nay, do la qua trinh mang lai niem vui, bang kha nang cua minh.

### Danh gia ve Tam:
 - Muc dich khong phai la de giai quyet van de ma chi don gian la Ban ron trong viec chung minh minh la nguoi gioi
 	+ Trong cai viec chung minh minh la nguoi gioi do, thi no se co roi rot dau do vai phan dinh vo du an.
 	+ Nhung muc dich cuoi cung la chung minh rang minh la nguoi gioi nhat, bang moi gia dat duoc dieu do :).

### Cac su that cua cuoc song:
 - Khong phai cu o vi tri cao la khong can lam gi thi moi viec deu co the dien ra.
 	+ O vi tri cao, no chi the hien duoc la nguoi do co kha nang lam duoc viec. Con neu o vi tri cao roi, ma khong lam viec, thi chang co dieu gi co the xay ra ca.
 - Hay trung thuc voi ban than, con nguoi va the gioi xung quanh trong moi luc.
 	+ Trung thuc la phuong phap tot nhat de han che van de den voi minh.
 	+ Mot khi ban khong trung thuc voi ban than, thi ngoai viec ban co gang de giai quyet cac van de
 		- Noi doi de lam diu noi dau tam thoi, no se mang den nhieu problem hon nua cho cuoc song cua ban sau nay.
 - Con nguoi rat de vo, doi xu voi con nguoi thi can nhan biet truoc ho o level nao:
 	+ Thuong dang: moi van de deu co the noi 1 cach toat mong heo voi nhung nguoi nhu the nay, ma chang he so ho gian.
 	+ Trung dang: ho chiu duoc 1 chut kho khan, nen doi voi nhung nguoi nay. Can tiep xuc van de mot cach an du, de ho co the lam.
 	+ Ha dang: ho khong chiu noi kho khan. Do do hay doi xu voi ho bang su nhe nhang nhat co the.

### Ban chat cua nong gian, chieu tro, tat ca moi dau kho tren cuoc doi:
 - La khong giai quyet duoc van de, ma muon nhan thanh qua ngot ngao ma viec giai thanh cong van de mang lai.
 	+ Giai quyet van de rat vui, vi no kho de dat den dich cuoi cung. Mot ngay 1 it, dan dan se thanh cong.
 	+ That bai khi co gang co nghia la con duong ma minh da di chua dung, no se khong mang lai thanh cong.

### De truong thanh:
 - Gia tri huong toi:
 	+ Can lam duoc nhieu (theo duoi su trung thuc)
 		- Co nhung dieu nen noi va khong nen noi.
 		- Neu da quyet dinh noi roi thi noi that.
 	+ Can kien nhan voi con nguoi (theo duoi su bac ai)
 	+ Khi ban dot lua len, thi nguoi ta se khong muon cung ban giai quyet van de nua.
 		+ Hi vong dieu tot dep se toi

 - Dieu quan trong la xac dinh vi the cua minh. Song voi vi the do va luon ghi nho dieu do.

=> Khi gap dieu phien nao, hay nho vi the cua minh can phai lam gi. Gia tri ma minh huong toi la gi.

 - Bieu hien cua nguoi truong thanh:
 	+ Luon luon lam viec mot cach chuyen nghiep.
 	+ Khong noi nong va giup do moi nguoi trong kha nang cho phep.

### Bi mat cua hanh phuc: con nguoi minh la tong hop cua cac cam xuc. Minh mang lai cho minh cam xuc tot thi no se vui.

 - La tap the duc: de khoe manh, bom tinh than yeu doi

 - La lam viec: de tan huong niem vui cua su hoan thanh, giup minh tranh duoc cac tham san si cua cuoc song. (Minh co kha nang lam viec, cac trai nghiem cua cuoc doi chung minh dieu do. Dieu minh can de phat huy no la ke hoach va su kien nhan, no se giup minh tan huong duoc niem vui cua cuoc song, tung chut tung chut mot)
 	+ De niem vui cua su hoan thanh thi can:
 		- Lap ke hoach
 		- Kien nhan thuc hien theo ke hoach
 		- Gap kho khan thi tiep tuc, tung buoc tung buoc. Den 1 luc nao do se giai quyet van de thanh cong.
 	+ Tranh duoc cac tham, san, si:
 		- Tham cac gia tri ma minh khong lam ra duoc.
 		- Tham cac danh ma minh khong dong gop cho cong dong.
 		- Tham cac tinh cam ma minh khong yeu thuong, vun dap.

 - La yeu thuong, hi vong: yeu thuong la tha thu cho cac loi lam cua nguoi khac.
 	+ Danh nguoi chay di, chu khong ai danh ke chay lai.
 	+ Nhung can can than hon, de dam bao minh khong bi qua dau.

 - Cuoc doi co nhieu noi dau, hay chap nhan no, bang hanh dong tung buoc tung buoc lam no mat di. Dung lam diu noi dau bang:
 	+ Loi noi doi
 	+ Chat kich thich
 	=> Ban dung no de lam cho minh bot dau, nhung no chi co tac dung tam thoi. Sau do no mang lai cho ban nhieu noi dau hon, va roi ban phai dung no voi lieu luong cao hon. Va cu nhu the ban se danh mat cai Chan, Thien, Mi cua ban.