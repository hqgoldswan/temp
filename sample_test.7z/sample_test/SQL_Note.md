
# SQL statement for Oracle:
## Select all table name in Oracle DB.
SELECT owner, table_name
  FROM dba_tables

SELECT owner, table_name
  FROM all_tables

SELECT table_name
  FROM user_tables


## Select top 10 statements
SELECT *
FROM PS_USER_MST
WHERE ROWNUM <= 10;


SELECT *
FROM C_STR_001
WHERE ROWNUM <= 2;

SELECT *
FROM C_STR_001
WHERE ROWNUM <= 1;

SELECT *
FROM C_STR_001
WHERE RCV_TM >= 0;

SELECT *
FROM C_STR_001
WHERE RCV_TM <= CURRENT_TIMESTAMP()
    AND ROWNUM <= 1;

## Select
WHERE s.start_date >= sysdate -7
      OR ack.acknowledge_date >= sysdate -7
      OR fin.finish_date >= sysdate -7;

## Get 1 hour old data:
SELECT *
FROM C_TRBL_TAB
WHERE ROWNUM <= 2;

SELECT *
FROM C_STR_186
WHERE ROWNUM <= 1;

### Get current timestamp
select CURRENT_TIMESTAMP
from dual;

### Get current timestamp
select LOCALTIMESTAMP
from dual;

## Oracle DB maniplution:
create table team (first_name varchar(20), last_name varchar(20) , sex varchar(10), age varchar(99));

### Create database having timestamp
create table quanle(DATA_TYPE number(1), HIS_START_DATE timestamp, HIS_END_DATE timestamp);

### Insert timestamp value
INSERT INTO TABLE_NAME (TIMESTAMP_VALUE)
VALUES (TO_TIMESTAMP('2014-07-02 06:14:00.742000000', 'YYYY-MM-DD HH24:MI:SS.FF'));

INSERT INTO quanle
VALUES (2, TO_TIMESTAMP('2014-07-02 06:14:00.7420000', 'YYYY-MM-DD HH24:MI:SS.FF'), TO_TIMESTAMP('2018-01-24 06:14:00.7420000', 'YYYY-MM-DD HH24:MI:SS.FF'));

-- if you want the current time stamp to be inserted then:
insert into tablename (timestamp_value)
values (CURRENT_TIMESTAMP);

insert into quanle
values (1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Checking curent table status after inserting
select *
from quanle;

