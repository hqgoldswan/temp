#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>

int deptnos[3] = { 000, 111, 222 };
int get_deptno() { return deptnos[2]; }
int *get_deptnoptr() { return &(deptnos[2]); }

void main()
{
    int x;
    char *y;
    int z;
    printf("%s\n", deptnos);
    x = deptnos[1];
    printf("%d\n", x);
}