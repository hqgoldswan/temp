
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[14];
};
static struct sqlcxp sqlfpn =
{
    13,
    "addempPROC.pc"
};


static unsigned int sqlctx = 550371;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[5];
   unsigned long  sqhstl[5];
            int   sqhsts[5];
            short *sqindv[5];
            int   sqinds[5];
   unsigned long  sqharm[5];
   unsigned long  *sqharc[5];
   unsigned short  sqadto[5];
   unsigned short  sqtdso[5];
} sqlstm = {12,5};

/* SQLLIB Prototypes */
extern sqlcxt (/*_ void **, unsigned int *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned int *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned int *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern void sqliem(/*_ unsigned char *, signed int * _*/);

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* CUD (Compilation Unit Data) Array */
static short sqlcud0[] =
{12,4130,832,0,0,
5,0,0,0,0,0,27,133,0,0,4,4,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,10,0,0,
36,0,0,2,49,0,4,146,0,0,1,0,0,1,0,2,3,0,0,
55,0,0,3,49,0,4,178,0,0,2,1,0,1,0,2,9,0,0,1,3,0,0,
78,0,0,4,90,0,3,189,0,0,5,5,0,1,0,1,3,0,0,1,9,0,0,1,9,0,0,1,3,0,0,1,3,0,0,
113,0,0,5,0,0,30,207,0,0,0,0,0,1,0,
128,0,0,6,0,0,32,214,0,0,0,0,0,1,0,
};


/*
NAME
  sample
FUNCTION
  Simple 32-bit Pro*C sample program from Pro*C User's Guide
NOTES

   sample  is a simple example program which adds new employee
           records to the personnel data base.  Checking
           is done to insure the integrity of the data base.
           The employee numbers are automatically selected using
           the current maximum employee number + 10.

           The program queries the user for data as follows:

           Enter employee name:
           Enter employee job:
           Enter employee salary:
           Enter employee dept:

           The program terminates if control Z (end of file) or null
           string (<return> key) is entered when the employee name
           is requested.

           If the record is successfully inserted, the following
           is printed:

           ename added to department dname as employee # nnnnnn


OWNER
  Clare
DATE
  05/01/84
MODIFIED
  dhood       12/23/09 - Use parse_args()
  dhood       12/23/09 - Changed askn() and asks() to use fgets()
  dhood       01/27/09 - Prompt for password
  kakiyama    05/05/97 - replaced sqlproto.h with sqlcpr.h
  rahmed      08/10/95 - No need yo define WIN_NT
  rahmed      07/05/95 - Removed all the warnings for NT.
  syau        03/07/95 - WIN_NT: add prototype files
  Hartenstine 04/27/93 - WIN_NT: Port to Windows NT
  dcriswel    04/11/92 - IBMC: Add .H to EXEC SQL INCLUDE
  bfotedar    01/07/92 - Included stdlib.h, modified compiling instructions
  bfotedar    11/22/91 - OS2_2: Port to OS/2 2.0
  Criswell    11/08/90 - Declared main() void
  Criswell    11/01/90 - Microsoft C 6.0 changes
  Okamura     07/05/89 - Update documentation for V6 on OS/2
  RPatterson  03/26/87 - Updated error handling.
  RPatterson  02/20/86 - Port: support Microsoft 'C' compiler and sqlmsc.lib.
  Clare       09/19/84 - Port: remove VMSisms.
  Clare       12/26/84 - Port IBM: fflush() prompts.
*/

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <sqlda.h>
#include <sqlcpr.h>

int errrpt(void);
int asks(char *,char *, int);
int askn(char *,int *);

/* Prototypes */
#if defined(__STDC__)
  void usage(char *prog);
  void parse_args(int argc, char **argv);
extern  int chg_echo(int echo_on);
#else
  void usage(char *);
  void parse_args(int, char **);
extern  int chg_echo(int echo_on);
#endif

#define MAX_USERNAME     31
#define MAX_SERVICENAME 128

extern char  username[];
extern char  password[];
extern char  service[ ];

/* EXEC SQL INCLUDE SQLCA.H;
 */ 
/*
 * $Header: sqlca.h 24-apr-2003.12:50:58 mkandarp Exp $ sqlca.h 
 */

/* Copyright (c) 1985, 2003, Oracle Corporation.  All rights reserved.  */
 
/*
NAME
  SQLCA : SQL Communications Area.
FUNCTION
  Contains no code. Oracle fills in the SQLCA with status info
  during the execution of a SQL stmt.
NOTES
  **************************************************************
  ***                                                        ***
  *** This file is SOSD.  Porters must change the data types ***
  *** appropriately on their platform.  See notes/pcport.doc ***
  *** for more information.                                  ***
  ***                                                        ***
  **************************************************************

  If the symbol SQLCA_STORAGE_CLASS is defined, then the SQLCA
  will be defined to have this storage class. For example:
 
    #define SQLCA_STORAGE_CLASS extern
 
  will define the SQLCA as an extern.
 
  If the symbol SQLCA_INIT is defined, then the SQLCA will be
  statically initialized. Although this is not necessary in order
  to use the SQLCA, it is a good pgming practice not to have
  unitialized variables. However, some C compilers/OS's don't
  allow automatic variables to be init'd in this manner. Therefore,
  if you are INCLUDE'ing the SQLCA in a place where it would be
  an automatic AND your C compiler/OS doesn't allow this style
  of initialization, then SQLCA_INIT should be left undefined --
  all others can define SQLCA_INIT if they wish.

  If the symbol SQLCA_NONE is defined, then the SQLCA variable will
  not be defined at all.  The symbol SQLCA_NONE should not be defined
  in source modules that have embedded SQL.  However, source modules
  that have no embedded SQL, but need to manipulate a sqlca struct
  passed in as a parameter, can set the SQLCA_NONE symbol to avoid
  creation of an extraneous sqlca variable.
 
MODIFIED
    lvbcheng   07/31/98 -  long to int
    jbasu      12/12/94 -  Bug 217878: note this is an SOSD file
    losborne   08/11/92 -  No sqlca var if SQLCA_NONE macro set 
  Clare      12/06/84 - Ch SQLCA to not be an extern.
  Clare      10/21/85 - Add initialization.
  Bradbury   01/05/86 - Only initialize when SQLCA_INIT set
  Clare      06/12/86 - Add SQLCA_STORAGE_CLASS option.
*/
 
#ifndef SQLCA
#define SQLCA 1
 
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ int     sqlabc;
         /* b4  */ int     sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ int     sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };

#ifndef SQLCA_NONE 
#ifdef   SQLCA_STORAGE_CLASS
SQLCA_STORAGE_CLASS struct sqlca sqlca
#else
         struct sqlca sqlca
#endif
 
#ifdef  SQLCA_INIT
         = {
         {'S', 'Q', 'L', 'C', 'A', ' ', ' ', ' '},
         sizeof(struct sqlca),
         0,
         { 0, {0}},
         {'N', 'O', 'T', ' ', 'S', 'E', 'T', ' '},
         {0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0}
         }
#endif
         ;
#endif
 
#endif
 
/* end SQLCA */


/* EXEC SQL BEGIN DECLARE SECTION; */ 

/* VARCHAR  user[31]; */ 
struct { unsigned short len; unsigned char arr[31]; } user;

/* VARCHAR  pass[31]; */ 
struct { unsigned short len; unsigned char arr[31]; } pass;

/* VARCHAR  svc[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } svc;
             /* Connect String                      */


int     empno;                     /* employee number                     */
/* VARCHAR ename[10 + 1]; */ 
struct { unsigned short len; unsigned char arr[11]; } ename;

                                   /* employee name                       */
int     deptno;                    /* department number                   */
/* VARCHAR dname[14 + 1]; */ 
struct { unsigned short len; unsigned char arr[15]; } dname;

                                   /* department name                     */

/* VARCHAR job[9 + 1]; */ 
struct { unsigned short len; unsigned char arr[10]; } job;

                                   /* employee job                        */
int     sal;                       /* employee salary                     */
/* EXEC SQL END DECLARE SECTION; */ 


int main(int argc, char** argv)
{

/* --------------------------------------------------------------------------
 logon to ORACLE, and open the cursors. The program exits if any errors occur.
-------------------------------------------------------------------------- */

   /* EXEC SQL WHENEVER SQLERROR GOTO errexit; */ 


  /* parse the command line arguments */
  parse_args(argc, argv);

  /* Assign the VARCHAR char array components */
  strncpy((char *) user.arr, (const char *) username, MAX_USERNAME);
  strncpy((char *) svc.arr,  (const char *) service,  MAX_SERVICENAME);
  strncpy((char *) pass.arr, (const char *) password, MAX_USERNAME);

  /* hide password */
  memset(password, 0, MAX_USERNAME);

  /* Assign the VARCHAR length components */
  user.len =  (unsigned short) strlen((char *) user.arr);
  pass.len =  (unsigned short) strlen((char *) pass.arr);
  svc.len  =  (unsigned short) strlen((char *)  svc.arr);

  printf("\nConnecting as %s@%s\n", user.arr, svc.arr);

  /* Connect to TimesTen or Oracle DB. */
  /* EXEC SQL CONNECT :user IDENTIFIED BY :pass USING :svc; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 4;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )10;
  sqlstm.offset = (unsigned int  )5;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (unsigned char  *)&user;
  sqlstm.sqhstl[0] = (unsigned long )33;
  sqlstm.sqhsts[0] = (         int  )33;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (unsigned char  *)&pass;
  sqlstm.sqhstl[1] = (unsigned long )33;
  sqlstm.sqhsts[1] = (         int  )33;
  sqlstm.sqindv[1] = (         short *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned long )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (unsigned char  *)&svc;
  sqlstm.sqhstl[2] = (unsigned long )130;
  sqlstm.sqhsts[2] = (         int  )130;
  sqlstm.sqindv[2] = (         short *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned long )0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlstm.sqlcmax = (unsigned int )100;
  sqlstm.sqlcmin = (unsigned int )2;
  sqlstm.sqlcincr = (unsigned int )1;
  sqlstm.sqlctimeout = (unsigned int )0;
  sqlstm.sqlcnowait = (unsigned int )0;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) goto errexit;
}



  /* hide password */
  memset(pass.arr, 0, MAX_USERNAME);
  pass.len = 0;

  printf("Connected\n\n");


/* --------------------------------------------------------------------------
   Retrieve the current maximum employee number
-------------------------------------------------------------------------- */

   /* EXEC SQL SELECT NVL(MAX(EMPNO),0) + 10
              INTO :empno
              FROM EMP; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 4;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "select (NVL(max(EMPNO),0)+10) into :b0  from EMP ";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )36;
   sqlstm.selerr = (unsigned short)1;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&empno;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto errexit;
}



/* --------------------------------------------------------------------------
   read the user's input from STDIN.  If the employee name is
   not entered, exit.
   Verify that the entered department number is valid and echo the
   department's name
-------------------------------------------------------------------------- */

   for( ; ; empno+=10 )
     {
     int l;

     /* Get employee name to be inserted. */
     l = asks("Enter employee name  : ", (char *)ename.arr, sizeof(ename.arr));

     if ( l <= 0 )
       break;

     ename.len = (short) l;

     job.len = (short) asks("Enter employee job   : ", (char *)job.arr, sizeof(job.arr));
     askn("Enter employee salary: ",&sal);

     for ( ; ; )
       {
       if ( askn("Enter employee dept  :   ",&deptno) < 0 )
         break;

       /* EXEC SQL WHENEVER NOT FOUND GOTO nodept; */ 

       /* EXEC SQL SELECT DNAME
                  INTO :dname
                  FROM DEPT
                  WHERE DEPTNO = :deptno; */ 

{
       struct sqlexd sqlstm;
       sqlstm.sqlvsn = 12;
       sqlstm.arrsiz = 4;
       sqlstm.sqladtp = &sqladt;
       sqlstm.sqltdsp = &sqltds;
       sqlstm.stmt = "select DNAME into :b0  from DEPT where DEPTNO=:b1";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )55;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)4352;
       sqlstm.occurs = (unsigned int  )0;
       sqlstm.sqhstv[0] = (unsigned char  *)&dname;
       sqlstm.sqhstl[0] = (unsigned long )17;
       sqlstm.sqhsts[0] = (         int  )0;
       sqlstm.sqindv[0] = (         short *)0;
       sqlstm.sqinds[0] = (         int  )0;
       sqlstm.sqharm[0] = (unsigned long )0;
       sqlstm.sqadto[0] = (unsigned short )0;
       sqlstm.sqtdso[0] = (unsigned short )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&deptno;
       sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
       sqlstm.sqhsts[1] = (         int  )0;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqinds[1] = (         int  )0;
       sqlstm.sqharm[1] = (unsigned long )0;
       sqlstm.sqadto[1] = (unsigned short )0;
       sqlstm.sqtdso[1] = (unsigned short )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqphss = sqlstm.sqhsts;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqpins = sqlstm.sqinds;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlstm.sqpadto = sqlstm.sqadto;
       sqlstm.sqptdso = sqlstm.sqtdso;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) goto nodept;
       if (sqlca.sqlcode < 0) goto errexit;
}



       dname.arr[dname.len] = '\0';

       /* EXEC SQL WHENEVER NOT FOUND STOP; */ 


       /* Here if deptno was found in dbs. Insert new employee into dbs. */

       /* EXEC SQL INSERT INTO EMP(EMPNO,ENAME,JOB,HIREDATE,SAL,DEPTNO)
                  VALUES (:empno,:ename,:job,sysdate,:sal,:deptno); */ 

{
       struct sqlexd sqlstm;
       sqlstm.sqlvsn = 12;
       sqlstm.arrsiz = 5;
       sqlstm.sqladtp = &sqladt;
       sqlstm.sqltdsp = &sqltds;
       sqlstm.stmt = "insert into EMP (EMPNO,ENAME,JOB,HIREDATE,SAL,DEPTNO)\
 values (:b0,:b1,:b2,sysdate,:b3,:b4)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )78;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)4352;
       sqlstm.occurs = (unsigned int  )0;
       sqlstm.sqhstv[0] = (unsigned char  *)&empno;
       sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
       sqlstm.sqhsts[0] = (         int  )0;
       sqlstm.sqindv[0] = (         short *)0;
       sqlstm.sqinds[0] = (         int  )0;
       sqlstm.sqharm[0] = (unsigned long )0;
       sqlstm.sqadto[0] = (unsigned short )0;
       sqlstm.sqtdso[0] = (unsigned short )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&ename;
       sqlstm.sqhstl[1] = (unsigned long )13;
       sqlstm.sqhsts[1] = (         int  )0;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqinds[1] = (         int  )0;
       sqlstm.sqharm[1] = (unsigned long )0;
       sqlstm.sqadto[1] = (unsigned short )0;
       sqlstm.sqtdso[1] = (unsigned short )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&job;
       sqlstm.sqhstl[2] = (unsigned long )12;
       sqlstm.sqhsts[2] = (         int  )0;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqinds[2] = (         int  )0;
       sqlstm.sqharm[2] = (unsigned long )0;
       sqlstm.sqadto[2] = (unsigned short )0;
       sqlstm.sqtdso[2] = (unsigned short )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&sal;
       sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
       sqlstm.sqhsts[3] = (         int  )0;
       sqlstm.sqindv[3] = (         short *)0;
       sqlstm.sqinds[3] = (         int  )0;
       sqlstm.sqharm[3] = (unsigned long )0;
       sqlstm.sqadto[3] = (unsigned short )0;
       sqlstm.sqtdso[3] = (unsigned short )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&deptno;
       sqlstm.sqhstl[4] = (unsigned long )sizeof(int);
       sqlstm.sqhsts[4] = (         int  )0;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqinds[4] = (         int  )0;
       sqlstm.sqharm[4] = (unsigned long )0;
       sqlstm.sqadto[4] = (unsigned short )0;
       sqlstm.sqtdso[4] = (unsigned short )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqphss = sqlstm.sqhsts;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqpins = sqlstm.sqinds;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlstm.sqpadto = sqlstm.sqadto;
       sqlstm.sqptdso = sqlstm.sqtdso;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) exit(1);
       if (sqlca.sqlcode < 0) goto errexit;
}



       printf("\n%s added to the %s department as employee number %d\n",
         ename.arr,dname.arr,empno);
       break;

       /* Here if deptno NOT found in dbs */
       nodept:
         printf("\nNo such department\n");
         continue;
       }
     }

/* --------------------------------------------------------------------------
   close the cursors and log off from TimesTen or Oracle DB
-------------------------------------------------------------------------- */

   /* EXEC SQL COMMIT WORK RELEASE; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 5;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )113;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto errexit;
}


   printf ("\nEnd of the Pro*C Sample example program.\n");
   return 0;

errexit:
   errrpt();
   /* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

   /* EXEC SQL ROLLBACK WORK RELEASE; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 5;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )128;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   return 1;
}

/*---------------------------------------------------------------------------
COUNT askn(text,variable)

   print the 'text' on STDOUT and read an integer variable from
   SDTIN.

   text points to the null terminated string to be printed
   variable points to an integer variable

   askn returns a 1 if the variable was read successfully or a
       -1 if -eof- was encountered
-------------------------------------------------------------------------- */

int askn(text,variable)
   char text[];
   int  *variable;
   {
   char s[20];

   printf(text);
   fflush(stdout);
   if ( fgets((char *) s, sizeof(s), stdin) == (char *) 0 )
     return(EOF);

   *variable = atoi(s);
   return(1);
   }

/* --------------------------------------------------------------------------
COUNT asks(text,variable)

   Printf the 'text' to STDOUT and read up to the size of the
   input buffer.

   Return either the length of the input string or 0 otherwise
----------------------------------------------------------------------- */

int asks(char * text, char * variable, int len)
{
  char * temp = NULL;
  char * cp   = NULL;
  char buf[50];

  printf(text);
  fflush(stdout);

  temp = fgets((char *) variable, len, stdin);
  if (NULL == temp) {
    printf("Bad input, exiting ...\n\n");
    return 0;
  }

  cp = (char *) strchr((char *) variable, '\n');

  if (cp == variable)
  {
    return 0;
  }

  if (cp)
      *cp = '\0';
  else
  {
    printf("Data may be truncated.\n");
    fgets((char *) buf, 50, stdin);
  }

  return strlen(variable);
}

/* --------------------------------------------------------------------------
int errrpt()

   errrpt prints the ORACLE error msg and number.
-------------------------------------------------------------------------- */

int errrpt( void )
   {
   printf("%.70s (%d)\n", sqlca.sqlerrm.sqlerrmc, -sqlca.sqlcode);
   return(0);
   }