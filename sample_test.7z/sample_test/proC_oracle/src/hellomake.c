#include <hellomake.h>

int main() {
  // call a function in another file
  myPrintHelloMake();

  myAddresTest();

  myProCtest();

  return(0);
}