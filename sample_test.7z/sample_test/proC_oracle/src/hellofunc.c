#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>
#include <hellomake.h>

#include "Ora_type.h"
#include "Oraerr.h"             /* A001 */
#include "TabInfo.h"
#include "CarOraerr.h"
#include "CarOrakey.h"

#define TBL_LEN 12

/* 複数:1
(表・カラム)検索用設定値格納配列 */
struct SqlSetValue
{
    char  db_name[17] ;     /* テーブル名称 */
    S_KEY sendmode[11] ;    /* 検索条件格納 */
};

int deptnos[3] = { 000, 111, 222 };
int get_deptno() { return deptnos[2]; }
int *get_deptnoptr() { return &(deptnos[2]); }

void myPrintHelloMake(void) {

  printf("Hello World!\n");

  return;
}

void myAddresTest(void) {
    int x;
    char *y;
    int z;
    printf("%d\n", &z);
    x = deptnos[1];
    printf("%d\n", x);
}

void myProCtest(void) {
    printf("%d\n", LEN_C_FUNC_HOSTNAME);
}