/* vim: set filetype=c : */
/**********************************************************************************************************
* �ե�����̾ : DB���������ѥ���������     �إå��ե�����
*==========================================================================================================
* ����       : DB���������ѥ��������֤��Ѥ���ץ������Ѥ�������Ǽ����
*==========================================================================================================
* <Ver.Rev> ����        ������  ����ID  ������      ����
*----------------------------------------------------------------------------------------------------------
* <000.001> 2014/12/16  JPC     -       ��ë��ʸ    ��������
* <000.002> 2015/10/28  IBP     CS-060  ��ë��ʸ    ��ξ�ޥ����������������ӥ塼�ɲ�
* <000.003> 2016/09/06  16���� CS-019 ���硡��    �۵޼�ξ�����ɲ�
* <000.004> 2016/10/12  MP		 CS-006 ���硡��    ��ư��ǽ��쥳������¾���ѹ�
*
*               All Rights Reserved, Copyright(C) 2014, Hitachi Industry & Control Solutions, Ltd.
***********************************************************************************************************
*/
#ifndef ORAFUNC_H_
#define ORAFUNC_H_

#include <stdio.h>

/*---------------------------------------------------------------------------------------------------------
* �������
*/
struct C_CARSNDHIS;
struct C_CARSNDLST;
struct C_CLCAR;
struct C_CLTKCAR;
struct C_CRNT;
struct C_CROSS;
struct C_DAYMAN;
struct C_EDIT;
struct C_FUNC;
struct C_ID;
struct C_JIAN;
struct C_JOB_DAY;
struct C_JYOUMUIN;
struct C_KINKYU;
struct C_LASTJOB;
/*--- ���������ɲ� --- <000.002> 2015/10/28 IBP CS-060 ��ë��ʸ ��ξ�ޥ����������������ӥ塼�ɲ� */
struct C_MSTSEND_VW;
/*--- �����ޤ��ɲ� --- <000.002> 2015/10/28 IBP CS-060 ��ë��ʸ ��ξ�ޥ����������������ӥ塼�ɲ� */
struct C_MST_REST;
struct C_NEWCARPIC;
struct C_PICNAME;
struct C_REMOTE;
struct C_RENRAKU_NO;
struct C_SPRTHIS;
struct C_SPRT_CAR;
struct C_SPRT_TERM;
struct C_STR;
struct C_STR_FileCopy;
struct C_STR_SCP;
struct C_SYSLOCK;
struct C_SYUHEN;
struct C_TELNO;
struct C_TELSEND;
struct C_TM_DAYMAN;
struct C_TRBL_CAR;
struct C_TRBL_MAN;
struct C_TRBL;
struct C_TUSIN_J;
struct C_UNCARSND;
struct PS_CLAS;
struct PS_CRNT;
struct strPS_CRNT_VW;
struct PS_GYOUTAI;
struct PS_IDOU;
struct PS_IMAGE_ID;
struct PS_JIAN_CRNT;
struct PS_KIJI_CRNT;
struct PS_KINMU_DTL;
struct PS_KINMU;
struct PS_REMOTE;
struct PS_RFID_MST;
struct PS_STR_FileCopy;
struct PS_STR;
struct PS_STR_SCP;
struct PS_SYOKUIN;
struct PS_SYOZOKU;
struct PS_TERM_PSD;
struct PS_TERM_PSW;
struct strPS_USER_CRNT_VW;
struct PS_USER_CRNT;
struct PS_USER;
struct STR_RFID_STATE;
struct T_TUSINGYOTO ;
/* ---���������ɲ�--- <000.003> 2016/09/06  16���� CS-019 ���硡��    �۵޼�ξ�����ɲ� */
struct STR_C_EMGRUN;
/* ---�����ޤ��ɲ�--- <000.003> 2016/09/06  16���� CS-019 ���硡��    �۵޼�ξ�����ɲ� */

/*---------------------------------------------------------------------------------------------------------
* �ץ��ȥ��������
*/

/* DB_BACKUP.pc */
int tblcopy(char *, char *, long *, char *) ;
int DB_FileIn(long) ;
int DB_FileOut(long) ;
int DB_FileIO(int, long, char *) ;
int DB_File_Reader(char *, char *, char *, char *) ;
int DB_STR_FileCopy(struct C_STR_FileCopy *, long *, char *) ;
int DB_PS_STR_FileCopy(struct PS_STR_FileCopy *, int *, char *) ;

/* DB_C_CARSNDHIS_TAB.pc */
int DB_C_CARSNDHIS_R(int, int, int, int, struct C_CARSNDHIS *, int, int, struct C_CARSNDHIS **, int *, int *, char *) ;
int DB_C_CARSNDHIS_W(struct C_CARSNDHIS *, int, int, int *, char *) ;
int DB_C_CARSNDHIS_U(int, int, struct C_CARSNDHIS *, struct C_CARSNDHIS *, int, int *, char *) ;
int DB_C_CARSNDHIS_D(int, int, struct C_CARSNDHIS *, int, int *, char *) ;
int DB_C_CARSNDHIS_C(int, int, struct C_CARSNDHIS *, int *, int *, char *) ;
int DB_C_CARSNDHIS_Excl(int *, char *) ;
int DB_C_CARSNDHIS_RNV(int, int, int, int, struct C_CARSNDHIS *, int, int, struct C_CARSNDHIS **, int *, int *, char *) ;
int DB_C_CARSNDHIS_RNVand(int, int, int, int, struct C_CARSNDHIS *, int, int, struct C_CARSNDHIS **, int *, int *, char *) ;

/* DB_C_CARSNDLST_TAB.pc */
int DB_C_CARSNDLST_R(int, int, int, int, struct C_CARSNDLST *, int, int, struct C_CARSNDLST **, int *, int *, char *) ;
int DB_C_CARSNDLST_W(struct C_CARSNDLST *, int, int, int *, char *) ;
int DB_C_CARSNDLST_U(int, int, struct C_CARSNDLST *, struct C_CARSNDLST *, int, int *, char *) ;
int DB_C_CARSNDLST_D(int, int, struct C_CARSNDLST *, int, int *, char *) ;
int DB_C_CARSNDLST_C(int, int, struct C_CARSNDLST *, int *, int *, char *) ;
int DB_C_CARSNDLST_Excl(int *, char *) ;

/* DB_C_CLCAR_MST.pc */
int DB_C_CLCAR_MST_R(char *, char *, struct C_CLCAR **, int *, int *, char *) ;
int DB_C_CLCAR_MST_RExcl(char *, char *, struct C_CLCAR **, int *, int *, char *) ;
int DB_C_CLCAR_MST_Rname(const char *, struct C_CLCAR **, int *, int *, char *);
int DB_C_CLCAR_MST_RnameExcl(char *, struct C_CLCAR **, int *, int *, char *);
int DB_C_CLCAR_MST_W(struct C_CLCAR *, int, char *) ;
int DB_C_CLCAR_MST_WNC(struct C_CLCAR *, int *, char *);
int DB_C_CLCAR_MST_U(struct C_CLCAR *, int *, char *) ;
int DB_C_CLCAR_MST_UNC(struct C_CLCAR *, int *, char *) ;
int DB_C_CLCAR_MST_Dname(char *, int *, char *) ;
int DB_C_CLCAR_MST_DnameNC(char *, int *, char *);
int DB_C_CLCAR_MST_Cname(char *, int *, int *, char *);

/* DB_C_CLTKCAR_MST.pc */
int DB_C_CLTKCAR_R(int search_pattern, int search_key, int order_key, int order_flag,
					struct C_CLTKCAR *DBSearchStruct, int max_num, int Excl,
					struct C_CLTKCAR **DBFindData, int *find_num, int *err_code, char *errstr) ;
int DB_C_CLTKCAR_W(struct C_CLTKCAR *DBAddStruct, int Add_num, int CommitFlag, int *err_code, char *errstr) ;
int DB_C_CLTKCAR_U(int, int, struct C_CLTKCAR *, struct C_CLTKCAR *, int, int *, char *) ;
int DB_C_CLTKCAR_D(int search_pattern, int search_key, struct C_CLTKCAR *DBDeleteStruct,
					int CommitFlag, int *err_code, char *errstr) ;
int DB_C_CLTKCAR_C(int search_pattern, int search_key, struct C_CLTKCAR *DBSearchStruct,
					int *find_num, int *err_code, char *errstr) ;

/* DB_C_CRNT_TAB.pc */
int DB_C_CRNT_TAB_R(char *, char *, struct C_CRNT **, int *, int *, char *) ;
int DB_C_CRNT_TAB_RExcl(char *prf_code, char *car_no, struct C_CRNT **wk, int *cnt, int *err, char *errstr) ;
int DB_C_CRNT_TAB_W(struct C_CRNT *, int *, char *) ;
int DB_C_CRNT_TAB_WNC(struct C_CRNT *, int *, char *) ;
int DB_C_CRNT_TAB_U(struct C_CRNT *, int *, char *) ;
int DB_C_CRNT_TAB_UNC(struct C_CRNT *, int *, char *) ;
int DB_C_CRNT_TAB_D(char *, char *, int *, char *) ;
int DB_C_CRNT_TAB_DNC(char *prf_code, char *car_no, int *err, char *errstr) ;
int DB_C_CRNT_TAB_C(char *, char *, int *, int *, char *) ;

/* DB_C_CROSS_MST.pc */
int DB_C_CROSS_R(int, int, int, int, struct C_CROSS *, int, int, struct C_CROSS **, int *, int *, char *) ;
int DB_C_CROSS_W(struct C_CROSS *, int, int, int *, char *) ;
int DB_C_CROSS_U(int, int, struct C_CROSS *, struct C_CROSS *, int, int *, char *) ;
int DB_C_CROSS_D(int, int, struct C_CROSS *, int, int *, char *) ;
int DB_C_CROSS_C(int, int, struct C_CROSS *, int *, int *, char *) ;
int DB_C_CROSS_CGR(int, int, struct C_CROSS *, int, int *, int *, char *) ;
int DB_C_CROSS_Excl(int *, char *) ;

/* DB_C_DAYMAN.pc */
int DB_C_DAYMAN_R(int, int, int, int, int, char **, struct C_DAYMAN *, int, int, struct C_DAYMAN **, int *, int *, char *) ;
int DB_C_DAYMAN_W(char *, struct C_DAYMAN *, int, int, int *, char *) ;
int DB_C_DAYMAN_U(int, int, char *, struct C_DAYMAN *, struct C_DAYMAN *, int, int *, char *) ;
int DB_C_DAYMAN_D(int, int, int, char **, struct C_DAYMAN *, int, int *, char *) ;
int DB_C_DAYMAN_C(int, int, int, char **, struct C_DAYMAN *, int *, int *, char *) ;

/* DB_C_EDIT_TAB.pc */
int DB_C_EDIT_R(int, int, int, int, struct C_EDIT *, int, int, struct C_EDIT **, int *, int *, char *) ;
int DB_C_EDIT_W(struct C_EDIT *, int, int, int *, char *) ;
int DB_C_EDIT_U(int, int, struct C_EDIT *, struct C_EDIT *, int, int *, char *) ;
int DB_C_EDIT_D(int, int, struct C_EDIT *, int, int *, char *) ;
int DB_C_EDIT_C(int, int, struct C_EDIT *, int *, int *, char *) ;
int DB_C_EDIT_Excl(int *, char *) ;

/* ---���������ɲ�--- <000.003> 2016/09/06  16���� CS-019 ���硡��    �۵޼�ξ�����ɲ� */
int DB_C_EMGRUN_R(int, int, int, int, struct STR_C_EMGRUN *, int, int, struct STR_C_EMGRUN **, int *, int *, char *) ;
int DB_C_EMGRUN_W(struct STR_C_EMGRUN *, int, int, int *, char *);
int DB_C_EMGRUN_U(int, int, struct STR_C_EMGRUN *, struct STR_C_EMGRUN *, int, int *, char *);
int DB_C_EMGRUN_D(int, int, struct STR_C_EMGRUN *, int, int *, char *);
int DB_C_EMGRUN_C(int, int, struct STR_C_EMGRUN *, int *, int *, char *);
int DB_C_EMGRUN_Excl(int *, char *);
/* ---�����ޤ��ɲ�--- <000.003> 2016/09/06  16���� CS-019 ���硡��    �۵޼�ξ�����ɲ� */

/* DB_C_FUNC_TAB.pc */
/* ---���������ѹ�-- <000.004> 2016/10/12 MP CS-006 ���硡��   ��ư��ǽ��쥳������¾���ѹ� */
//int DB_C_FUNC_TAB_R(int, struct C_FUNC **, int *, int *, char *) ;
//int DB_C_FUNC_TAB_RExcl(int, struct C_FUNC **, int *, int *, char *) ;
//int DB_C_FUNC_TAB_W(struct C_FUNC *, int *, char *) ;
//int DB_C_FUNC_TAB_U(struct C_FUNC *, int *, char *) ;
//int DB_C_FUNC_TAB_D(int, int *, char *) ;
//int DB_C_FUNC_TAB_C(int, int *, int *, char *) ;
int DB_C_FUNC_TAB_R(int, int, struct C_FUNC *,struct C_FUNC **, int *, int *, char *) ;
int DB_C_FUNC_TAB_RExcl(int, int, struct C_FUNC *, struct C_FUNC **, int *, int *, char *) ;
int DB_C_FUNC_TAB_W(struct C_FUNC *, int, int *, char *) ;
int DB_C_FUNC_TAB_U(int, struct C_FUNC *, int, int *, char *) ;
int DB_C_FUNC_TAB_D(int, int, struct C_FUNC *, int, int *, char *) ;
int DB_C_FUNC_TAB_C(int, struct C_FUNC *, int *, int *, char *) ;
/* ---�����ޤ��ѹ�-- <000.004> 2016/10/12 MP CS-006 ���硡��   ��ư��ǽ��쥳������¾���ѹ� */

/* DB_C_ID_MST.pc */
int DB_C_ID_MST_R(char *id, struct C_ID **wk, int *cnt, int *err, char *errstr);
int DB_C_ID_MST_RExcl(char *, struct C_ID **, int *, int *, char *) ;
int DB_C_ID_MST_Rname(const char *car_name, struct C_ID **wk, int *cnt, int *err, char *errstr);
int DB_C_ID_MST_RnameExcl(char *car_name, struct C_ID **wk, int *cnt, int *err, char *errstr);
int DB_C_ID_MST_W(struct C_ID *, int *, char *) ;
int DB_C_ID_MST_WNC(struct C_ID *, int *, char *) ;
int DB_C_ID_MST_U(struct C_ID *, int *, char *) ;
int DB_C_ID_MST_UNC(struct C_ID *wk, int *err, char *errstr);
int DB_C_ID_MST_D(char *, int *, char *) ;
int DB_C_ID_MST_DNC(char *, int *, char *) ;
int DB_C_ID_MST_C(char *, int *, int *, char *) ;

/* DB_C_JIAN_TAB.pc */
int DB_C_JIAN_TAB_R(char *, struct C_JIAN **, int *, int *, char *) ;
int DB_C_JIAN_TAB_Rlimit(char *, int, int, struct C_JIAN **, int *, int *, char *) ;
int DB_C_JIAN_TAB_RExcl(char *, struct C_JIAN **, int *, int *, char *) ;
int DB_C_JIAN_TAB_W(struct C_JIAN *, int *, char *) ;
int DB_C_JIAN_TAB_WNC(struct C_JIAN *, int *, char *) ;
int DB_C_JIAN_TAB_U(struct C_JIAN *, int *, char *) ;
int DB_C_JIAN_TAB_D(char *, int *, char *) ;
int DB_C_JIAN_TAB_DNC(char *, int *, char *) ;
int DB_C_JIAN_TAB_C(char *, int *, int *, char *) ;
int DB_C_JIAN_TAB_Excl(int *, char *) ;

/* DB_C_JOB_DAY.pc */
int DB_C_JOB_DAY_R(int, int, int, int, int, char **, struct C_JOB_DAY *, int, int, struct C_JOB_DAY **, int *, int *, char *) ;
int DB_C_JOB_DAY_W(char *, struct C_JOB_DAY *, int, int, int *, char *) ;
int DB_C_JOB_DAY_U(int, int, char *, struct C_JOB_DAY *, struct C_JOB_DAY *, int, int *, char *) ;
int DB_C_JOB_DAY_D(int, int, int, char **, struct C_JOB_DAY *, int, int *, char *) ;
int DB_C_JOB_DAY_C(int, int, int, char **, struct C_JOB_DAY *, int *, int *, char *) ;

/* DB_C_JYOUMUIN_MST.pc */
int DB_C_JYOUMUIN_MST_R(char *, struct C_JYOUMUIN **, int *, int *, char *) ;
int DB_C_JYOUMUIN_MST_RExcl(char *, struct C_JYOUMUIN **, int *, int *, char *) ;
int DB_C_JYOUMUIN_MST_W(struct C_JYOUMUIN *, int *, char *) ;
int DB_C_JYOUMUIN_MST_U(struct C_JYOUMUIN *, int *, char *) ;
int DB_C_JYOUMUIN_MST_D(char *, int *, char *) ;
int DB_C_JYOUMUIN_MST_C(char *, int *, int *, char *) ;

/* DB_C_KINKYU_TAB.pc */
int DB_C_KINKYU_R(int, int, int, int, int, char **, struct C_KINKYU *, int, int,
					struct C_KINKYU **, int *, int *, char *) ;
int DB_C_KINKYU_W(char *, struct C_KINKYU *, int, int, int *, char *) ;
int DB_C_KINKYU_U(int, int, char *, struct C_KINKYU *, struct C_KINKYU *, int, int *, char *) ;
//int DB_C_KINKYU_D() ;
int DB_C_KINKYU_C(int, int, int, char **, struct C_KINKYU *, int *, int *, char *) ;

/* DB_C_LASTJOB_TAB.pc */
int DB_C_LASTJOB_R(int, int, int, int, struct C_LASTJOB *, int, int, struct C_LASTJOB **, int *, int *, char *) ;
int DB_C_LASTJOB_W(struct C_LASTJOB *, int, int, int *, char *) ;
int DB_C_LASTJOB_U(int, int, struct C_LASTJOB *, struct C_LASTJOB *, int, int *, char *) ;
int DB_C_LASTJOB_D(int, int, struct C_LASTJOB *, int, int *, char *) ;
int DB_C_LASTJOB_C(int, int, struct C_LASTJOB *, int *, int *, char *) ;
int DB_C_LASTJOB_Excl(int *, char *) ;

/* DB_C_MERIT_TAB.pc */
//int DB_C_MERIT_TAB_R(C_MERIT_KEY, C_MERIT **, int *, int *, char *) ;
//int DB_C_MERIT_TAB_RExcl(C_MERIT_KEY, C_MERIT **, int *, int *, char *) ;
//int DB_C_MERIT_TAB_W(C_MERIT *, int *, char *) ;
//int DB_C_MERIT_TAB_WNC(C_MERIT *, int *, char *) ;
//int DB_C_MERIT_TAB_U(C_MERIT *, int *, char *) ;
//int DB_C_MERIT_TAB_UNC(C_MERIT *, int *, char *) ;
//int DB_C_MERIT_TAB_Dname(C_MERIT_KEY, int *, char *) ;
//int DB_C_MERIT_TAB_DnameNC(C_MERIT_KEY, int *, char *) ;
//int DB_C_MERIT_TAB_C(C_MERIT_KEY, int *, int *, char *) ;

/*--- ���������ɲ� --- <000.002> 2015/10/28 IBP CS-060 ��ë��ʸ ��ξ�ޥ����������������ӥ塼�ɲ� */
/* DB_C_MSTSEND_VIEW.pc */
int DB_C_MSTSEND_VIEW_R(int, int, int, int, struct C_MSTSEND_VW *, int,
						struct C_MSTSEND_VW **, int *, int *, char *) ;
int DB_C_MSTSEND_VIEW_C(int, int, struct C_MSTSEND_VW *, int *, int *, char *) ;
/*--- �����ޤ��ɲ� --- <000.002> 2015/10/28 IBP CS-060 ��ë��ʸ ��ξ�ޥ����������������ӥ塼�ɲ� */

/* DB_C_MST_REST_TAB.pc */
int DB_C_MST_REST_R(int, int, int, int, struct C_MST_REST *, int, int, struct C_MST_REST **, int *, int *, char *) ;
int DB_C_MST_REST_W(struct C_MST_REST *, int, int, int *, char *) ;
int DB_C_MST_REST_U(int, int, struct C_MST_REST *, struct C_MST_REST *, int, int *, char *) ;
int DB_C_MST_REST_D(int, int, struct C_MST_REST *, int, int *, char *) ;
int DB_C_MST_REST_C(int, int, struct C_MST_REST *, int *, int *, char *) ;

/* DB_C_NEWCARPIC_TAB.pc */
int DB_C_NEWCARPIC_R(int search_pattern, int search_key, int order_key, int order_flag,
						struct C_NEWCARPIC *DBSearchStruct, int max_num, int Excl,
						struct C_NEWCARPIC **DBFindData, int *find_num, int *err_code, char *errstr) ;
int DB_C_NEWCARPIC_W(struct C_NEWCARPIC *, int, int, int *, char *) ;
int DB_C_NEWCARPIC_U(int, int, struct C_NEWCARPIC *, struct C_NEWCARPIC *, int, int *, char *) ;
int DB_C_NEWCARPIC_D(int, int, struct C_NEWCARPIC *, int, int *, char *) ;
int DB_C_NEWCARPIC_C(int, int, struct C_NEWCARPIC *, int *, int *, char *) ;
int DB_C_NEWCARPIC_Excl(int *, char *) ;

/* DB_C_PICNAME_TAB.pc */
int DB_C_PICNAME_R(int, int, int, int, struct C_PICNAME *, int, int, struct C_PICNAME **, int *, int *, char *) ;
int DB_C_PICNAME_W(struct C_PICNAME *, int, int, int *, char *) ;
int DB_C_PICNAME_U(int, int, struct C_PICNAME *, struct C_PICNAME *, int, int *, char *) ;
int DB_C_PICNAME_D(int, int, struct C_PICNAME *, int, int *, char *) ;
int DB_C_PICNAME_C(int, int, struct C_PICNAME *, int *, int *, char *) ;
int DB_C_PICNAME_Excl(int *, char *) ;

/* DB_C_REMOTE_TAB.pc */
int DB_C_REMOTE_R(int, int, int, int, struct C_REMOTE *, int, int, struct C_REMOTE **, int *, int *, char *) ;
int DB_C_REMOTE_W(struct C_REMOTE *, int, int, int *, char *) ;
int DB_C_REMOTE_U(int, int, struct C_REMOTE *, struct C_REMOTE *, int, int *, char *) ;
int DB_C_REMOTE_D(int, int, struct C_REMOTE *, int, int *, char *) ;
int DB_C_REMOTE_C(int, int, struct C_REMOTE *, int *, int *, char *) ;
int DB_C_REMOTE_Excl(int, char *) ;

/* DB_C_RENRAKU_NO_TAB.pc */
int DB_C_RENRAKU_NO_R(int, int, int, int, struct C_RENRAKU_NO *, int, int, struct C_RENRAKU_NO **, int *, int *, char *) ;
int DB_C_RENRAKU_NO_W(struct C_RENRAKU_NO *, int, int, int *, char *) ;
int DB_C_RENRAKU_NO_U(int, int, struct C_RENRAKU_NO *, struct C_RENRAKU_NO *, int, int *, char *) ;
int DB_C_RENRAKU_NO_D(int, int, struct C_RENRAKU_NO *, int, int *, char *) ;
int DB_C_RENRAKU_NO_C(int, int, struct C_RENRAKU_NO *, int *, int *, char *) ;
int DB_C_RENRAKU_NO_Excl(int, char *) ;

/* DB_C_SPRTHIS_TAB.pc */
int DB_C_SPRTHIS_R(int, int, int, int, struct C_SPRTHIS *, int, int,
					struct C_SPRTHIS **, int *, int *, char *) ;
int DB_C_SPRTHIS_W(struct C_SPRTHIS *, int, int, int *, char *) ;
int DB_C_SPRTHIS_U(int, int, struct C_SPRTHIS *, struct C_SPRTHIS *, int, int *, char *) ;
int DB_C_SPRTHIS_D(int, int, struct C_SPRTHIS *, int, int *, char *) ;
int DB_C_SPRTHIS_C(int, int, struct C_SPRTHIS *, int *, int *, char *) ;
int DB_C_SPRTHIS_Excl(int, char *) ;

/* DB_C_SPRT_CAR_TAB.pc */
int DB_C_SPRT_CAR_R(int, int, int, int, struct C_SPRT_CAR *, int, int,
                    struct C_SPRT_CAR **, int *, int *, char *) ;
int DB_C_SPRT_CAR_W(struct C_SPRT_CAR *, int, int, int *, char *) ;
int DB_C_SPRT_CAR_U(int, int, struct C_SPRT_CAR *, struct C_SPRT_CAR *, int, int *, char *) ;
int DB_C_SPRT_CAR_D(int, int, struct C_SPRT_CAR *, int, int *, char *) ;
int DB_C_SPRT_CAR_C(int, int, struct C_SPRT_CAR *, int *, int *, char *) ;
int DB_C_SPRT_CAR_Excl(int, char *) ;

/* DB_C_SPRT_TERM_TAB.pc */
int DB_C_SPRT_TERM_R(int, int, int, int, struct C_SPRT_TERM *, int, int, struct C_SPRT_TERM **, int *, int *, char *) ;
int DB_C_SPRT_TERM_W(struct C_SPRT_TERM *, int, int, int *, char *) ;
int DB_C_SPRT_TERM_U(int, int, struct C_SPRT_TERM *, struct C_SPRT_TERM *, int, int *, char *) ;
int DB_C_SPRT_TERM_D(int, int, struct C_SPRT_TERM *, int, int *, char *) ;
int DB_C_SPRT_TERM_C(int, int, struct C_SPRT_TERM *, int *, int *, char *) ;
int DB_C_SPRT_TERM_Excl(int *, char *) ;

/* DB_C_STR.pc */
int DB_C_STR_R(char *, char *, char *, struct C_STR **, int *, int *, char *) ;
int DB_C_STR_RExcl(char *, char *, char *, struct C_STR **, int *, int *, char *) ;
int DB_C_STR_W(char *, struct C_STR *, int *, char *) ;
int DB_C_STR_WNC(char *, struct C_STR *, int *, char *) ;
int DB_C_STR_U(char *, struct C_STR *, int *, char *) ;
int DB_C_STR_D(char *, char *, char *, int *, char *) ;
int DB_AllDelete(char *, int *, char *) ;
int DB_C_STR_C(char *, char *, char *, int *, int *, char *) ;
int DB_C_STR_Rlimit(char *, int, char (*)[20], char *, char *, int, int, struct C_STR **, int *, int *, char *) ;
int DB_C_STR_RlimitExcl(char *, int, char (*)[20], char *, char *, int, int, struct C_STR **, int *, int *, char *) ;
int tblmerge(char *, char *, int *, char *) ;
int DB_C_STR_DBetWeen(char *, char *, char *, int *, char *) ;

/* DB_C_STR_SCP_TAB.pc */
int DB_C_STR_SCP_R(int, int, int, int, struct C_STR_SCP *, int, int, struct C_STR_SCP **, int *, int *, char *) ;
int DB_C_STR_SCP_W(struct C_STR_SCP *, int, int, int *, char *) ;
int DB_C_STR_SCP_U(int, int, struct C_STR_SCP *, struct C_STR_SCP *, int, int *, char *) ;
int DB_C_STR_SCP_D(int, int, struct C_STR_SCP *, int, int *, char *) ;
int DB_C_STR_SCP_C(int, int, struct C_STR_SCP *, int *, int *, char *) ;

/* DB_C_SYSLOCK_TAB.pc */
int DB_C_SYSLOCK_R(int, int, int, int, struct C_SYSLOCK *, int, int, struct C_SYSLOCK **, int *, int *, char *) ;
int DB_C_SYSLOCK_W(struct C_SYSLOCK *, int, int, int *, char *) ;
int DB_C_SYSLOCK_U(int, int, struct C_SYSLOCK *, struct C_SYSLOCK *, int, int *, char *) ;
int DB_C_SYSLOCK_D(int, int, struct C_SYSLOCK *, int, int *, char *) ;
int DB_C_SYSLOCK_C(int, int, struct C_SYSLOCK *, int *, int *, char *) ;
int DB_C_SYSLOCK_Excl(int *, char *) ;

/* DB_C_SYUHEN_TAB.pc */
int DB_C_SYUHEN_R(int, int, int, int, struct C_SYUHEN *, int, int, struct C_SYUHEN **, int *, int *, char *) ;
int DB_C_SYUHEN_W(struct C_SYUHEN *, int, int, int *, char *) ;
int DB_C_SYUHEN_U(int, int, struct C_SYUHEN *, struct C_SYUHEN *, int, int *, char *) ;
int DB_C_SYUHEN_D(int, int, struct C_SYUHEN *, int, int *, char *) ;
int DB_C_SYUHEN_C(int, int, struct C_SYUHEN *, int *, int *, char *) ;
int DB_C_SYUHEN_Excl(int *, char *) ;

/* DB_C_TELNO_MST.pc */
int DB_C_TELNO_R(int, int, int, int, struct C_TELNO *, int, int, struct C_TELNO **, int *, int *, char *) ;
int DB_C_TELNO_W(struct C_TELNO *, int, int, int *, char *) ;
int DB_C_TELNO_U(int, int, struct C_TELNO *, struct C_TELNO *, int, int *, char *) ;
int DB_C_TELNO_D(int, int, struct C_TELNO *, int, int *, char *) ;
int DB_C_TELNO_C(int, int, struct C_TELNO *, int *, int *, char *) ;
int DB_C_TELNO_Excl(int, char *) ;

/* DB_C_TELSEND_TAB.pc */
int DB_C_TELSEND_R(int, int, int, int, struct C_TELSEND *, int, int, struct C_TELSEND **, int *, int *, char *) ;
int DB_C_TELSEND_W(struct C_TELSEND *, int, int, int *, char *) ;
int DB_C_TELSEND_U(int, int, struct C_TELSEND *, struct C_TELSEND *, int, int *, char *) ;
int DB_C_TELSEND_D(int, int, struct C_TELSEND *, int, int *, char *) ;
int DB_C_TELSEND_C(int, int, struct C_TELSEND *, int *, int *, char *) ;
int DB_C_TELSEND_Excl(int *, char *) ;

/* DB_C_TM_DAYMAN.pc */
int DB_C_TM_DAYMAN_R(int, int, int, int, int, char **, struct C_TM_DAYMAN *, int, int, struct C_TM_DAYMAN **, int *, int *, char *) ;
int DB_C_TM_DAYMAN_W(char *, struct C_TM_DAYMAN *, int, int, int *, char *) ;
int DB_C_TM_DAYMAN_U(int, int, char *, struct C_TM_DAYMAN *, struct C_TM_DAYMAN *, int, int *, char *) ;
int DB_C_TM_DAYMAN_D(int, int, int, char **, struct C_TM_DAYMAN *, int, int *, char *) ;
int DB_C_TM_DAYMAN_C(int, int, int, char **, struct C_TM_DAYMAN *, int *, int *, char *) ;

/* DB_C_TRBL_CAR_TAB.pc */
int DB_C_TRBL_CAR_TAB_R(char *, struct C_TRBL_CAR **, int *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_Rlimit(char *, int, int, struct C_TRBL_CAR **, int *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_RExcl(char *, struct C_TRBL_CAR **, int *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_W(struct C_TRBL_CAR *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_WNC(struct C_TRBL_CAR *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_U(struct C_TRBL_CAR *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_D(char *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_DNC(char *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_C(char *, int *, int *, char *) ;
int DB_C_TRBL_CAR_TAB_Excl(int *, char *) ;

/* DB_C_TRBL_MAN_TAB.pc */
int DB_C_TRBL_MAN_TAB_R(char *, struct C_TRBL_MAN **, int *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_Rlimit(char *, int, int, struct C_TRBL_MAN **, int *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_RExcl(char *, struct C_TRBL_MAN **, int *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_W(struct C_TRBL_MAN *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_WNC(struct C_TRBL_MAN *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_U(struct C_TRBL_MAN *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_D(char *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_DNC(char *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_C(char *, int *, int *, char *) ;
int DB_C_TRBL_MAN_TAB_Excl(int *, char *) ;

/* DB_C_TRBL_TAB.pc */
int DB_C_TRBL_TAB_R(char *, struct C_TRBL **, int *, int *, char *) ;
int DB_C_TRBL_TAB_Rno(char *, char *, struct C_TRBL **, int *, int *, char *) ;
int DB_C_TRBL_TAB_Rlimit(char *, int, int, struct C_TRBL **, int *, int *, char *) ;
int DB_C_TRBL_TAB_RExcl(char *, struct C_TRBL **, int *, int *, char *) ;
int DB_C_TRBL_TAB_RnoExcl(char *, char *, struct C_TRBL **, int *, int *, char *) ;
int DB_C_TRBL_TAB_W(struct C_TRBL *, int *, char *) ;
int DB_C_TRBL_TAB_WNC(struct C_TRBL *, int *, char *) ;
int DB_C_TRBL_TAB_U(struct C_TRBL *, int *, char *) ;
int DB_C_TRBL_TAB_D(char *, int *, char *) ;
int DB_C_TRBL_TAB_DNC(char *, int *, char *) ;
int DB_C_TRBL_TAB_C(char *, int *, int *, char *) ;
int DB_C_TRBL_TAB_Cno(char *, char *, int *, int *, char *) ;
int DB_C_TRBL_TAB_Excl(int *, char *) ;

/* DB_C_TUSIN_J_TAB.pc */
int DB_C_TUSIN_J_TAB_R(char *, struct C_TUSIN_J **, int *, int *, char *);
int DB_C_TUSIN_J_TAB_RExcl(char *, struct C_TUSIN_J **, int *, int *, char *) ;
int DB_C_TUSIN_J_TAB_W(struct C_TUSIN_J *, int *, char *) ;
int DB_C_TUSIN_J_TAB_U(struct C_TUSIN_J *, int *, char *) ;
int DB_C_TUSIN_J_TAB_D(char *, int *, char *) ;
int DB_C_TUSIN_J_TAB_C(char *, int *, int *, char *) ;

/* DB_C_UNCARSEND_TAB.pc */
int DB_C_UNCARSND_R(int, int, int, int, struct C_UNCARSND *, int, int, struct C_UNCARSND **, int *, int *, char*) ;
int DB_C_UNCARSND_W(struct C_UNCARSND *, int, int, int *, char *) ;
int DB_C_UNCARSND_U(int, int, struct C_UNCARSND *, struct C_UNCARSND *, int, int *, char *) ;
int DB_C_UNCARSND_D(int, int, struct C_UNCARSND *, int, int *, char *) ;
int DB_C_UNCARSND_C(int, int, struct C_UNCARSND *, int *, int *, char *) ;
int DB_C_UNCARSND_Excl(int *, char *) ;
int DB_C_UNCARSND_RNV(int, int, int, int, struct C_UNCARSND *, int, int, struct C_UNCARSND **, int *, int *, char *) ;

/* DB_Com.pc */
int DB_Open(int *, char *) ;
int DB_Close(int *, char *) ;
int DB_COMMIT() ;
int DB_ROLLBACK() ;
int numcheck(char *);
void DB_free(void *p_addr);
int DB_File_Read(char *);
int DBtrGetTime(int, char *);
int DB_Exclusive(char *, int, int *, char *) ;
char Char2hex(char *);
void ChangeCharCode(char *, size_t, char *, size_t) ;
int DB_TriggerEnable(const char *, int *, char *) ;
int DB_TriggerDisable(const char *, int *, char *) ;

/* DB_MST_AD.pc */
int DB_MST_AD(int, int, int *, char *) ;

/* DB_PS_CLAS_MST.pc */
int DB_PS_CLAS_MST_R(int, int, int, int, struct PS_CLAS *, int, int,
						struct PS_CLAS **, int *, int *, char *) ;
int DB_PS_CLAS_MST_W(struct PS_CLAS *, int, int, int *, int *, char *) ;
int DB_PS_CLAS_MST_U(int, int, struct PS_CLAS *, struct PS_CLAS *, int, int *, int *, char *) ;
int DB_PS_CLAS_MST_D(int, int, struct PS_CLAS *, int, int *, int *, char *) ;

/* DB_PS_CRNT_TAB.pc */
int DB_PS_CRNT_TAB_R(int, int, int, int, struct PS_CRNT *, int, int,
						struct PS_CRNT **, int *, int *, char *) ;
int DB_PS_CRNT_TAB_W(struct PS_CRNT *, int, int, int *, int *, char *errstr) ;
int DB_PS_CRNT_TAB_U(int, int, struct PS_CRNT *, struct PS_CRNT *, int, int *, int *, char *) ;
int DB_PS_CRNT_TAB_D(int, int, struct PS_CRNT *, int, int *, int *, char *) ;
int DB_PS_CRNT_TAB_C(int, int, struct PS_CRNT *, int *, int *, char *) ;
int DB_PS_CRNT_TAB_Excl(int *, char *) ;

/* DB_PS_CRNT_VIEW.pc */
int DB_PS_CRNT_VIEW_R(int, int, int, int, struct strPS_CRNT_VW *, int,
						struct strPS_CRNT_VW **, int *, int *, char *) ;
int DB_PS_CRNT_VIEW_C(int, int, struct strPS_CRNT_VW *, int *, int *, char *) ;

/* DB_PS_GYOUTAI_MST.pc */
int DB_PS_GYOUTAI_MST_R(int, int, int, int, struct PS_GYOUTAI *, int, int,
						struct PS_GYOUTAI **, int *, int *, char *) ;
int DB_PS_GYOUTAI_MST_W(struct PS_GYOUTAI *, int, int, int *, int *, char *) ;
int DB_PS_GYOUTAI_MST_U(int, int, struct PS_GYOUTAI *, struct PS_GYOUTAI *, int, int *, int *, char *) ;
int DB_PS_GYOUTAI_MST_D(int, int, struct PS_GYOUTAI *, int, int *, int *, char *) ;

/* DB_PS_IDOU_MST.pc */
int DB_PS_IDOU_MST_R(int, int, int, int, struct PS_IDOU *, int, int,
						struct PS_IDOU **, int *, int *, char *) ;
int DB_PS_IDOU_MST_W(struct PS_IDOU *, int, int, int *, int *, char *) ;
int DB_PS_IDOU_MST_U(int, int, struct PS_IDOU *, struct PS_IDOU *, int, int *, int *, char *) ;
int DB_PS_IDOU_MST_D(int, int, struct PS_IDOU *, int, int *, int *, char *) ;

/* DB_PS_IMAGE_ID_TAB.pc */
int DB_PS_IMAGE_ID_TAB_R(int, int, int, int, struct PS_IMAGE_ID *, int, int,
							struct PS_IMAGE_ID **, int *, int *, char *) ;
int DB_PS_IMAGE_ID_TAB_W(struct PS_IMAGE_ID *, int, int, int *, int *, char *) ;
int DB_PS_IMAGE_ID_TAB_U(int, int, struct PS_IMAGE_ID *, struct PS_IMAGE_ID *, int, int *, int *, char *) ;
int DB_PS_IMAGE_ID_TAB_D(int, int, struct PS_IMAGE_ID *, int, int *, int *, char *) ;
int DB_PS_IMAGE_ID_TAB_C(int, int, struct PS_IMAGE_ID *,int *, int *, char *) ;
int DB_PS_IMAGE_ID_TAB_Excl(int *, char *) ;

/* DB_PS_JIAN_CRNT_TAB.pc */
int DB_PS_JIAN_CRNT_TAB_R(int, int, int, int, struct PS_JIAN_CRNT *, int, int,
							struct PS_JIAN_CRNT **, int *, int *, char *) ;
int DB_PS_JIAN_CRNT_TAB_W(struct PS_JIAN_CRNT *, int, int, int *, int *, char *) ;
int DB_PS_JIAN_CRNT_TAB_U(int, int, struct PS_JIAN_CRNT *, struct PS_JIAN_CRNT *, int, int *, int *, char *) ;
int DB_PS_JIAN_CRNT_TAB_D(int, int, struct PS_JIAN_CRNT *, int, int *, int *, char *) ;
int DB_PS_JIAN_CRNT_TAB_C(int, int, struct PS_JIAN_CRNT *, int *, int *, char *) ;
int DB_PS_JIAN_CRNT_TAB_Excl(int *, char *) ;
int DB_PS_JIAN_CRNT_Dlimit(char *, char *, int, int *, int *, char *) ;

/* DB_PS_KIJI_CRNT_TAB.pc */
int DB_PS_KIJI_CRNT_TAB_R(int, int, int, int, struct PS_KIJI_CRNT *, int, int,
							struct PS_KIJI_CRNT **, int *, int *, char *) ;
int DB_PS_KIJI_CRNT_TAB_W(struct PS_KIJI_CRNT *, int, int, int *, int *, char *) ;
int DB_PS_KIJI_CRNT_TAB_U(int, int, struct PS_KIJI_CRNT *, struct PS_KIJI_CRNT *, int, int *, int *, char *) ;
int DB_PS_KIJI_CRNT_TAB_D(int, int, struct PS_KIJI_CRNT *, int, int *, int *, char *) ;
int DB_PS_KIJI_CRNT_TAB_C(int, int, struct PS_KIJI_CRNT *, int *, int *, char *) ;
int DB_PS_KIJI_CRNT_TAB_Excl(int *, char *) ;

/* DB_PS_KINMU_DTL_MST.pc */
int DB_PS_KINMU_DTL_MST_R(int, int, int, int, struct PS_KINMU_DTL *, int, int,
							struct PS_KINMU_DTL **, int *, int *, char *) ;
int DB_PS_KINMU_DTL_MST_W(struct PS_KINMU_DTL *, int, int, int *, int *, char *) ;
int DB_PS_KINMU_DTL_MST_U(int, int, struct PS_KINMU_DTL *, struct PS_KINMU_DTL *, int, int *, int *, char *) ;
int DB_PS_KINMU_DTL_MST_D(int, int, struct PS_KINMU_DTL *, int, int *, int *, char *) ;

/* DB_PS_KINMU_MST.pc */
int DB_PS_KINMU_MST_R(int, int, int, int, struct PS_KINMU *, int, int,
						struct PS_KINMU **, int *, int *, char *) ;
int DB_PS_KINMU_MST_W(struct PS_KINMU *, int, int, int *, int *, char *) ;
int DB_PS_KINMU_MST_U(int, int, struct PS_KINMU *, struct PS_KINMU *, int, int *, int *, char *) ;
int DB_PS_KINMU_MST_D(int, int, struct PS_KINMU *, int, int *, int *, char *) ;

/* DB_PS_REMOTE_TAB.pc */
int DB_PS_REMOTE_R(int, int, int, int, struct PS_REMOTE *, int, int,
					struct PS_REMOTE **, int *, int *, char *) ;
int DB_PS_REMOTE_W(struct PS_REMOTE *, int, int, int *, int *, char *) ;
int DB_PS_REMOTE_U(int, int, struct PS_REMOTE *, struct PS_REMOTE *, int, int *, int *, char *) ;
int DB_PS_REMOTE_D(int, int, struct PS_REMOTE *, int, int *, int *, char *) ;
//int DB_PS_REMOTE_C(int, int, struct PS_REMOTE *, int *, int *, char *) ;
int DB_PS_REMOTE_Excl(int *, char *) ;

/* DB_PS_RFID_MST.pc */
int DB_PS_RFID_MST_R(long, long, long, long, struct PS_RFID_MST *, long, long,
						struct PS_RFID_MST **, long *, long *, char *) ;
int DB_PS_RFID_MST_C(long, long, struct PS_RFID_MST *, long *, long *, char *) ;
int DB_PS_RFID_MST_Excl(int *, char *) ;

/* DB_PS_STR.pc */
int DB_PS_STR_R(char *, int, int, int, int, struct PS_STR *, int, int,
				struct PS_STR **, int *, int *, char *) ;
int DB_PS_STR_W(char *, struct PS_STR *, int, int, int *, int *, char *) ;
int DB_PS_STR_U(char *, int, int, struct PS_STR *, struct PS_STR *, int, int *, int *, char *) ;
int DB_PS_STR_D(char *, int, int, struct PS_STR *, int, int *, int *, char *) ;
int DB_PS_STR_C(char *, int, int, struct PS_STR *, int *, int *, char *) ;
int DB_PS_STR_Excl( char *, int *, char *) ;
int DB_PS_STR_Rlimit(char *, char *, char *, char *, char *, int, int,
						struct PS_STR **, int *, int *, char *) ;
int DB_PS_STR_Rlimit2(char *, char *, char *, int, int,
						struct PS_STR **, int *, int *, char *) ;
int DB_PS_STR_DBetWeen(char *, char *, char *, int *, char *) ;
int DB_PSD_AllDelete(char *, int *) ;

/* DB_PS_STR_SCP_TAB.pc */
int DB_PS_STR_SCP_R(int, int, int, int, struct PS_STR_SCP *, int, int,
					struct PS_STR_SCP **, int *, int *, char *) ;
int DB_PS_STR_SCP_W(struct PS_STR_SCP *, int, int, int *, int *, char *) ;
int DB_PS_STR_SCP_U(int, int, struct PS_STR_SCP *, struct PS_STR_SCP *, int, int *, int *, char *) ;
int DB_PS_STR_SCP_D(int, int, struct PS_STR_SCP *, int, int *, int *, char *) ;
int DB_PS_STR_SCP_C(int, int, struct PS_STR_SCP *, int *, int *, char *) ;
int DB_PS_STR_SCP_Excl(int *, char *) ;

/* DB_PS_SYOKUIN_MST.pc */
int DB_PS_SYOKUIN_MST_R(int, int, int, int, struct PS_SYOKUIN *, int, int,
						struct PS_SYOKUIN **, int *, int *, char *) ;
int DB_PS_SYOKUIN_MST_W(struct PS_SYOKUIN *, int, int, int *, int *, char *) ;
int DB_PS_SYOKUIN_MST_U(int, int, struct PS_SYOKUIN *, struct PS_SYOKUIN *, int, int *, int *, char *) ;
int DB_PS_SYOKUIN_MST_D(int, int, struct PS_SYOKUIN *, int, int *, int *, char *) ;

/* DB_PS_SYOZOKU_MST.pc */
int DB_PS_SYOZOKU_MST_R(int, int, int, int, struct PS_SYOZOKU *, int, int,
						struct PS_SYOZOKU **, int *, int *, char *) ;
int DB_PS_SYOZOKU_MST_W(struct PS_SYOZOKU *, int, int, int *, int *, char *) ;
int DB_PS_SYOZOKU_MST_U(int, int, struct PS_SYOZOKU *, struct PS_SYOZOKU *, int, int *, int *, char *) ;
int DB_PS_SYOZOKU_MST_D(int, int, struct PS_SYOZOKU *, int, int *, int *, char *) ;

/* DB_PS_TERM_PSD_MST.pc */
int DB_PS_TERM_PSD_MST_R(int, int, int, int, struct PS_TERM_PSD *, int, int,
							struct PS_TERM_PSD **, int *, int *, char *) ;
int DB_PS_TERM_PSD_MST_W(struct PS_TERM_PSD *, int, int, int *, int *, char *) ;
int DB_PS_TERM_PSD_MST_U(int, int, struct PS_TERM_PSD *, struct PS_TERM_PSD *, int, int *, int *, char *) ;
int DB_PS_TERM_PSD_MST_D(int, int, struct PS_TERM_PSD *, int, int *, int *, char *) ;

/* DB_PS_TERM_PSW_MST.pc */
int DB_PS_TERM_PSW_MST_R(int, int, int, int, struct PS_TERM_PSW *, int, int,
							struct PS_TERM_PSW **, int *, int *, char *) ;
int DB_PS_TERM_PSW_MST_W(struct PS_TERM_PSW *, int, int, int *, int *, char *) ;
int DB_PS_TERM_PSW_MST_U(int, int, struct PS_TERM_PSW *, struct PS_TERM_PSW *, int, int *, int *, char *) ;
int DB_PS_TERM_PSW_MST_D(int, int, struct PS_TERM_PSW *, int, int *, int *, char *) ;

/* DB_PS_USCRNT_VIEW.pc */
int DB_PS_USER_CRNT_VIEW_R(int, int, int, int, struct strPS_USER_CRNT_VW *, int,
							struct strPS_USER_CRNT_VW **, int *, int *, char *) ;
int DB_PS_USER_CRNT_VIEW_C(int, int, struct strPS_USER_CRNT_VW *, int *, int *, char *) ;

/* DB_PS_USER_CRNT_TAB.pc */
int DB_PS_USER_CRNT_TAB_R(int, int, int, int, struct PS_USER_CRNT *, int, int,
							struct PS_USER_CRNT **, int *, int *, char *) ;
int DB_PS_USER_CRNT_TAB_W(struct PS_USER_CRNT *, int, int, int *, int *, char *) ;
int DB_PS_USER_CRNT_TAB_U(int, int, struct PS_USER_CRNT *, struct PS_USER_CRNT *, int, int *, int *, char *) ;
int DB_PS_USER_CRNT_TAB_D(int, int, struct PS_USER_CRNT *, int, int *, int *, char *) ;
int DB_PS_USER_CRNT_TAB_C(int, int, struct PS_USER_CRNT *, int *, int *, char *) ;
int DB_PS_USER_CRNT_TAB_Excl(int *, char *) ;

/* DB_PS_USER_MST.pc */
int DB_PS_USER_MST_R(int, int, int, int, struct PS_USER *, int, int,
						struct PS_USER **, int *, int *, char *) ;
int DB_PS_USER_MST_W(struct PS_USER *, int, int, int *, int *, char *) ;
int DB_PS_USER_MST_U(int, int, struct PS_USER *, struct PS_USER *, int, int *, int *, char *) ;
int DB_PS_USER_MST_D(int, int, struct PS_USER *, int, int *, int *, char *) ;

/* DB_RFID_STATE_TAB.pc */
int DB_RFID_STATE_R(int, int, int, int, struct STR_RFID_STATE *, int, int, struct STR_RFID_STATE **, int *, int *, char *) ;
int DB_RFID_STATE_W(struct STR_RFID_STATE *, int, int, int *, int *, char *) ;
int DB_RFID_STATE_U(int, int, struct STR_RFID_STATE *, struct STR_RFID_STATE *, int, int *, int *, char *) ;
int DB_RFID_STATE_D(int, int, struct STR_RFID_STATE *, int, int *, int *, char *) ;
int DB_RFID_STATE_C(int, int, struct STR_RFID_STATE *, int *, int *, char *) ;

/* DB_T_TUSINGYOTO.pc */
int DB_T_TUSINGYOTO_R(int, int, int, int, int, char **, struct T_TUSINGYOTO *, int, int, struct T_TUSINGYOTO **, int *, int *, char *) ;
int DB_T_TUSINGYOTO_W(char *, struct T_TUSINGYOTO *, int, int, int *, char *) ;
int DB_T_TUSINGYOTO_U(int, int, char *, struct T_TUSINGYOTO *, struct T_TUSINGYOTO *, int, int *, char *) ;
int DB_T_TUSINGYOTO_D(int, int, int, char **, struct T_TUSINGYOTO *, int, int *, char *) ;
int DB_T_TUSINGYOTO_C(int, int, int, char **, struct T_TUSINGYOTO *, int *, int *, char *) ;
int DB_T_TUSINGYOTO_Excl(int, char **, int *, char *) ;

/* GetErrToReturn.pc */
int GetErrToReturn(int, int) ;

/* GetTabInfo.pc */
int GetTableSize(int dbno) ;
//ColInfoTab *GetTableInfo(int);
char *GetTableName(int);
int ErrorReturn(int *, int, int, char *); 

/* MakeClause.pc */
void MakeSelColNameClause(int, char *) ;
//void MakeSelGrpColNameClause(int, S_KEY *, char *) ;
void MakeSQLHeadClause(int, int, char *) ;
void MakeInsValueClause(int, void *, char *) ;
void MakeUpdSetClause(int, void *, char *) ;
//void MakeDBComWhereClause(int, S_KEY *, char *) ;
//void MakeDBComOrderByClause(int, S_KEY *, char *) ;
//void MakeDBComGroupByClause(int, S_KEY *, char *) ;

#endif /* ORAFUNC_H_ */
