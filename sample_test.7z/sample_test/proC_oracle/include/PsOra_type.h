/* vim: set filetype=c : */
#ifndef _PSORA_TYPE_H_
#define _PSORA_TYPE_H_
/*----------------------------------------------------------------------------*
 * File Name    : PsOra_type.h
 *----------------------------------------------------------------------------
 * Function     : 
 * Description  : 
 * Author       : <2011.02.28> S.Sgawara
 * ===========================================================================
 * Change activity:
 * <ver/rev><Quick No> Date       <Orgin>      <Description>
 * ----------------------------------------------------------------------------
 * <MZP-1.00><XXX-XXX> 2011.02.28 <S.Sugawara> ��������
 * <001.001><ST-322>   2014/02/11 <T.Murakami] [NIP] �Ǽ��Ĳ�����Ͽ���б�
 * <001.002><NIP><X-041> 2015/02/10 <M.Hamatani> �桼�����Ѿ��������ӥ塼�ɲ�
 * <001.003><JPC><-----> 2015/03/12 <W.Kimura>   ���������ӥ塼�ɲ�
 *----------------------------------------------------------------------------*/

/*----------------------------------------
  �������
  ----------------------------------------*/
#define PS		4		/* PSD/PSW����  */

/*----------------------------------------
        PSD/PSW�ط�
----------------------------------------*/
/* �桼�������ޥ��� */
struct PS_USER {
       char    user_id[8];
       char    syokuin_no[8];
       char    vib_flg_kinkyu[1+3];
       char    vol_kinkyu[1+3];
       char    vib_flg_issei[1+3];
       char    vol_issei[1+3];
       char    vib_flg_110[1+3];
       char    vol_110[1+3];
       char    vib_flg_con[1+3];
       char    vol_flg_con[1+3];
       char    vib_pair_cut[1+3];
       char    vol_pair_cut[1+3];
       char    vib_pair_fail[1+3];
       char    vol_pair_fail[1+3];
       char    char_size[1+3];
       char    img_size[1+3];
       char    photo_light[1+3];
       char    auto_focus[1+3];
       char    white_balance[1+3];
       char    macro_set[1+3];
       char    func_ptn_code_hosyu[5+3];
       char    func_ptn_code_kanri[5+3];
       char    func_ptn_code_hyouji[5+3];
       char    data_term_ptn_code[5+3];
       char    up_date_user[14+2];
       char    up_date_pass[14+2];
       char    yuukou_kikan[3+1];
       char    init_pass_period[1+3];
       char    aut_req_num[3+1];
       char    aut_err_limit[3+1];
       char    up_date_aut[14+2];
} ;

/* �ǡ���ü�������ޥ��� */
struct PS_TERM_PSD {
       char    data_term_code[10+2];
       char    data_term_name[32];
       char    msisdn[12];
       char    tel_no[11+1];
       char    ez_no[30+2];
       char    iccid[19+1];
       char    kanri_syozoku_code[5+3];
       char    up_date[14+2];
} ;

/* PSW��̵���������ޥ��� */
struct PS_TERM_PSW {
       char    psw_term_code[9+3];
       char    bluetooth_dev_add[12];
       char    pin_code[32];
       char    wireless_base_name[40];
       char    kanri_syozoku_code[5+3];
       char    psw_base_code[9+3];
       char    up_date[14+2];
} ;

/* ���ְ����ޥ��� */
struct PS_GYOUTAI {
       char    gyoutai_code[5+3];
       char    gyoutai_name[40];
       char    ryaku[4];
       char    hyouji_jyunjyo[3+1];
       char    gyoutai_sokui_int[4];
       char    tokusyu_gyoutai_kubun[1+3];
       char    map_icon_r[3+1];
       char    map_icon_g[3+1];
       char    map_icon_b[3+1];
       char    del_flg[1+3];
       char    up_date[14+2];
} ;

/* ��̳��ʬ�����ޥ��� */
struct PS_KINMU {
       char    kinmu_kubun_code[5+3];
       char    kinmu_kubun_name[40];
       char    kinmu_kubun_type[1+3];
       char    hyouji_jyunjyo[2+2];
       char    up_date[14+2];
} ;

/* ��̳��ʬ�ٰܺ����ޥ��� */
struct PS_KINMU_DTL {
       char    kinmu_kubun_code_syousai[5+3];
       char    kinmu_kubun_name_syousai[40];
       char    kinmu_kubun_name_syousai_kana[40];
       char    ido[15+1];
       char    keido[16];
       char    tel_no[11+1];
       char    kinmu_kubun_code[5+3];
       char    syozoku_code[5+3];
       char    hyouji_jyunjyo[4];
       char    up_date[14+2];
} ;

/* ��°�����ޥ��� */
struct PS_SYOZOKU {
       char    syozoku_code[5+3];
       char    syozoku_name[20];
       char    syozoku_name_kana[40];
       char    tel_no[11+1];
       char    ido[15+1];
       char    keido[16];
       char    syozoku_kubun[1+3];
       char    syozoku_ptn_code[5+3];
       char    hyouji_obj_flg[1+3];
       char    hyouji_jyunjyo[3+1];
       char    up_date[14+2];
} ;

/* ���������ޥ��� */
struct PS_SYOKUIN {
       char    syokuin_no[8];
       char    syokuin_name[20];
       char    syokuin_name_kana[32];
       char    syozoku_code[5+3];
       char    kaikyuu_code[5+3];
       char    up_date[14+2];
} ;

/* ��ư���ʰ����ޥ��� */
struct PS_IDOU {
       char    idou_code[5+3];
       char    idou_name[40];
       char    idou_ryaku[4];
       char    hyouji_jyunjyo[10+2];
       char    gm_symbol_name[128];
       char    up_date[14+2];
} ;

/* ��������ޥ��� */
struct PS_CLAS {
       char    data_clas_code[5+3] ;
       char    data_clas_name[40];
       char    clas_kubun_code[5+3] ;
       char    up_date[14+2] ; 
} ;


/* PSD/PSW���� */
struct PS_CRNT {
       char    term_type[1+3];
       char    data_term_code[10+2];
       char    user_id[8+4];
       char    syozoku_code[5+3];
       char    pair_type[10+2];
       char    gyoutai_code[5+3];
       char    bumon_code[5+3];
       char    kinmu_kubun_code[5+3];
       char    kinmu_kubun_code_syousai[5+3];
       char    pair_stat[1+3];
       char    pair_date[14+2];
       char    get_reason[2+2];
       char    ido[15+1];
       char    keido[16+4];
       char    koudo[8+4];
       char    seido[1+3];
       char    sokui_date[14+2];
       char    send_time[14+2];
       char    login_stat[1+3];
       char    login_date[14+2];
       char    logout_date[14+2];
       char    start_gyoumu_stat[1+3];
       char    start_gyoumu_date[14+2];
       char    lock_stat[1+3];
       char    lock_date[14+2];
       char    init_stat[1+3];
       char    init_date[14+2];
       char    tobikoe_stat[1+3];
       char    tobikoe_date[14+2];
       char    version[10+2];
       char    version_get_date[14+2];
       char    taiou_stat[1+3];
       char    taiou_date[14+2];
       char    gentyaku_date[14+2];
       char    taiou_type[1+3];
       char    obj_key[10+2];
       char    idou_syudan[5+3];
       char    battery_power[1+3];
       char    denpa_stat[1+3];
       char    up_date[14+2];
       char    kennai_flg[1+3];
       char    recv_con[1+3];
       char    chg_tm[14+2];
       char    rcv_tm[14+2];
} ;

/* PDS/PSW��¸ */
struct PS_STR {
       char    term_type[1+3];
       char    data_term_code[10+2];
       char    user_id[8+4];
       char    syozoku_code[5+3];
       char    pair_type[10+2];
       char    gyoutai_code[5+3];
       char    bumon_code[5+3];
       char    kinmu_kubun_code[5+3];
       char    kinmu_kubun_code_syousai[5+3];
       char    pair_stat[1+3];
       char    pair_date[14+2];
       char    get_reason[2+2];
       char    ido[15+1];
       char    keido[16+4];
       char    koudo[8+4];
       char    seido[1+3];
       char    sokui_date[14+2];
       char    send_time[14+2];
       char    login_stat[1+3];
       char    login_date[14+2];
       char    logout_date[14+2];
       char    start_gyoumu_stat[1+3];
       char    start_gyoumu_date[14+2];
       char    lock_stat[1+3];
       char    lock_date[14+2];
       char    init_stat[1+3];
       char    init_date[14+2];
       char    tobikoe_stat[1+3];
       char    tobikoe_date[14+2];
       char    version[10+2];
       char    version_get_date[14+2];
       char    taiou_stat[1+3];
       char    taiou_date[14+2];
       char    gentyaku_date[14+2];
       char    taiou_type[1+3];
       char    obj_key[10+2];
       char    idou_syudan[5+3];
       char    battery_power[1+3];
       char    denpa_stat[1+3];
       char    up_date[14+2];
       char    kennai_flg[1+3];
       char    recv_con[1+3];
       char    chg_tm[14+2];
       char    rcv_tm[14+2];
} ;


/* PDS/PSW��¸���ִ��� */
struct PS_STR_SCP {
       int      mtype ;
       char    str_st [8] ;
       char    str_ed [8] ;
       char    rest_st [8] ;
       char    rest_ed [8] ;
};


/* PDS/PSW��⡼�ȥʥ� */
struct PS_REMOTE {
       char    term_type[1+3];
       char    term_code[10+2];
       char    jyusyo[40+4] ;
       char    ido[15+1] ;
       char    keido[16+4] ;
       char    shiji_tm[14+2] ;
       char    rcv_tm[14+2] ;
       char    hostname[20] ;
       char    jyoutai[1+3] ;
       char    remotenavi[1+3] ;
} ;

struct PS_STR_FileCopy
{
        char  tbname[128] ;     /* �ơ��֥�̾�� */
        char  tbdate[9] ;       /* �б����� (yyyymmdd) */
};


/* RFID���� */
struct PS_RFID_LINK {
        char  rfid[8] ;              /* RFID����         */
        char  data_term_code[10+2] ; /* �ǡ���ü�������� */
        char  set_date[14+2] ;       /* ��������         */
} ;


/* RFID�ޥ��� */
struct PS_RFID_MST {
        char  rfid[8] ;         /* RFID����         */
        char  rfid_name[10+2] ; /* RFID̾��         */
        char  syozoku_cd[14+2] ;/* ��°������       */
} ;

/* JPS �桼�������Ѿ���DB �ɲ� 2012.01.19 Y.Komatsu  Add START*/

/* �桼�������Ѿ�������DB */
struct PS_USER_CRNT {
		char	user_id[8] ;
		char	syozoku_code[5+3] ;
		char	login_stat[1+3] ;	
		char	login_date[14+2] ;
		char	logout_date[14+2] ;
		char	userlock_stat[1+3] ;
		char	send_int_flg[1+3] ;
		char	send_interval[4] ;
		char	send_int_limit[14+2] ;
		char	up_date[14+2] ;
} ;

/*--- ���������ɲ� --- <001.002><NIP><X-041> 2015/02/10 <M.Hamatani> �桼�����Ѿ��������ӥ塼�ɲ� */
/* �桼�������Ѿ�������DB */
typedef struct strPS_USER_CRNT_VW {
	char	user_id[PS_USCRNT_USER_ID_LEN+1]				;
	char	syozoku_code[PS_USCRNT_SYOZOKU_CD_LEN+1]		;
	char	login_stat[PS_USCRNT_LOGIN_STAT_LEN+1]			;
	char	login_date[PS_USCRNT_LOGIN_DATE_LEN+1]			;
	char	logout_date[PS_USCRNT_LOGOUT_DATE_LEN+1]		;
	char	userlock_stat[PS_USCRNT_LOCK_STAT_LEN+1]		;
	char	send_int_flg[PS_USCRNT_SEND_FLG_LEN+1]			;
	char	send_interval[PS_USCRNT_SEND_INTERVAL_LEN+1]	;
	char	send_int_limit[PS_USCRNT_SEND_LIMIT_LEN+1]		;
	char	up_date[PS_USCRNT_UP_DATE_LEN+1]				;
	char	syokuin_name[PS_SYOKUIN_SYOKUIN_NAME_LEN+1]		;
} PS_USER_CRNT_VW ;
/*--- �����ޤ��ɲ� --- <001.002><NIP><X-041> 2015/02/10 <M.Hamatani> �桼�����Ѿ��������ӥ塼�ɲ� */

/* 110�ֻ��ư���DB */
struct PS_JIAN_CRNT {
		char	info_id[10] ;
		char	jian_key[24] ;
		char	jian_no[5+3] ;
		char	rcv_tm[14+2] ;
} ;

/* JPS �桼�������Ѿ���DB �ɲ� 2012.01.19 Y.Komatsu  Add END  */

/* KMP ����DB �ɲ� 2012.12.29 T.Futaesaku  Add START */

/* ����DB */
struct PS_KIJI_CRNT {
		char	kiji_id[10+2] ;
		char	subject[40] ;
		char	dtlinfo[800] ;	
		char	load_date[14+2] ;
		char	load_st[14+2] ;
		char	load_en[14+2] ;
		char	syozoku[5+3] ;
		char	staff[20] ;
		char	maisu[4+4] ;									/* �����������           [NIP][ST-322] */
		char	image_id[5][10+2] ;								/* ��������ID             [NIP][ST-322] */
} ;

/* KMP ����DB �ɲ� 2012.12.29 T.Futaesaku  Add END */

/* �Ż߲���ID����DB [NIP][ST-323] */
struct PS_IMAGE_ID {
		char	image_id [10+2];								/* ����ID                               */
		char	updt_time[14+2];								/* ��������                             */
		char	kiji_id  [10+2];								/* ����ID                               */
		char	load_end [14+2];								/* �����Ǻܴ���                         */
		char	recv_time[14+2];								/* ��������                             */
};

/*--- ���������ɲ� --- <001.003><JPC><-----> 2015/03/12 <W.Kimura>   ���������ӥ塼�ɲ� */
/* ��������view */
typedef struct strPS_CRNT_VW {
	char	term_type[PS_CRNT_TERM_TYPE_LEN+1]								;
	char	data_term_code[PS_CRNT_DATA_TERM_CODE_LEN+1]					;
	char	user_id[PS_CRNT_USER_ID_LEN+1]									;
	char	syozoku_code[PS_CRNT_SYOZOKU_CODE_LEN+1]						;
	char	pair_type[PS_CRNT_PAIR_TYPE_LEN+1]								;
	char	gyoutai_code[PS_CRNT_GYOUTAI_CODE_LEN+1]						;
	char	bumon_code[PS_CRNT_BUMON_CODE_LEN+1]							;
	char	kinmu_kubun_code[PS_CRNT_KINMU_KUBUN_CODE_LEN+1]				;
	char	kinmu_kubun_code_syousai[PS_CRNT_KINMU_KUBUN_CODE_SYOUSAI_LEN+1];
	char	pair_stat[PS_CRNT_PAIR_STAT_LEN+1]								;
	char	pair_date[PS_CRNT_PAIR_DATE_LEN+1]								;
	char	get_reason[PS_CRNT_GET_REASON_LEN+1]							;
	char	ido[PS_CRNT_IDO_LEN+1]											;
	char	keido[PS_CRNT_KEIDO_LEN+1]										;
	char	koudo[PS_CRNT_KOUDO_LEN+1]										;
	char	seido[PS_CRNT_SEIDO_LEN+1]										;
	char	sokui_date[PS_CRNT_SOKUI_DATE_LEN+1]							;
	char	send_time[PS_CRNT_SEND_TIME_LEN+1]								;
	char	login_stat[PS_CRNT_LOGIN_STAT_LEN+1]							;
	char	login_date[PS_CRNT_LOGIN_DATE_LEN+1]							;
	char	logout_date[PS_CRNT_LOGOUT_DATE_LEN+1]							;
	char	start_gyoumu_stat[PS_CRNT_START_GYOUMU_STAT_LEN+1]				;
	char	start_gyoumu_date[PS_CRNT_START_GYOUMU_DATE_LEN+1]				;
	char	lock_stat[PS_CRNT_LOCK_STAT_LEN+1]								;
	char	lock_date[PS_CRNT_LOCK_DATE_LEN+1]								;
	char	init_stat[PS_CRNT_INIT_STAT_LEN+1]								;
	char	init_date[PS_CRNT_INIT_DATE_LEN+1]								;
	char	tobikoe_stat[PS_CRNT_TOBIKOE_STAT_LEN+1]						;
	char	tobikoe_date[PS_CRNT_TOBIKOE_DATE_LEN+1]						;
	char	version[PS_CRNT_VERSION_LEN+1]									;
	char	version_get_date[PS_CRNT_VERSION_GET_DATE_LEN+1]				;
	char	taiou_stat[PS_CRNT_TAIOU_STAT_LEN+1]							;
	char	taiou_date[PS_CRNT_TAIOU_DATE_LEN+1]							;
	char	gentyaku_date[PS_CRNT_GENTYAKU_DATE_LEN+1]						;
	char	taiou_type[PS_CRNT_TAIOU_TYPE_LEN+1]							;
	char	obj_key[PS_CRNT_OBJ_KEY_LEN+1]									;
	char	idou_syudan[PS_CRNT_IDOU_SYUDAN_LEN+1]							;
	char	battery_power[PS_CRNT_BATTERY_POWER_LEN+1]						;
	char	denpa_stat[PS_CRNT_DENPA_STAT_LEN+1]							;
	char	up_date[PS_CRNT_UP_DATE_LEN+1]									;
	char	kennai_flg[PS_CRNT_KENNAI_FLG_LEN+1]							;
	char	recv_con[PS_CRNT_RECV_CON_LEN+1]								;
	char	chg_tm[PS_CRNT_CHG_TM_LEN+1]									;
	char	rcv_tm[PS_CRNT_RCV_TM_LEN+1]									;
	char	syokuin_no[PS_USER_SYOKUIN_NO_LEN+1]							;
	char	syokuin_name[PS_SYOKUIN_SYOKUIN_NAME_LEN+1]						;
	char	kaikyuu_code[PS_SYOKUIN_KAIKYUU_CODE_LEN+1]						;
	char	data_clas_name[PS_CLAS_CLAS_NAME_LEN+1]							;
	char	carid[RFID_STATE_CARID_LEN+1]									;
	char	car_name[RFID_STATE_CAR_NAME_LEN+1]								;
	char	set_time[RFID_STATE_SET_TIME_LEN+1]								;
} PS_CRNT_VW ;
/*--- �����ޤ��ɲ� --- <001.003><JPC><-----> 2015/03/12 <W.Kimura>   ���������ӥ塼�ɲ� */

#endif /* _PSORA_TYPE_H_ */

